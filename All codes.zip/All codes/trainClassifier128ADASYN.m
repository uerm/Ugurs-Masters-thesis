function T = trainClassifier128ADASYN(trainingData)

indices = crossvalind('Kfold',trainingData(:,end),10);

% Linear SVM
targetsLinSVM128ADASYNtrain_all = [];
predsLinSVM128ADASYNtrain_all = [];
scoresLinSVM128ADASYNtrain_all = [];

targetsLinSVM128ADASYNtest_all = [];
predsLinSVM128ADASYNtest_all = [];
scoresLinSVM128ADASYNtest_all = [];

% Quadratic SVM
targetsQuadSVM128ADASYNtrain_all = [];
predsQuadSVM128ADASYNtrain_all = [];
scoresQuadSVM128ADASYNtrain_all = [];

targetsQuadSVM128ADASYNtest_all = [];
predsQuadSVM128ADASYNtest_all = [];
scoresQuadSVM128ADASYNtest_all = [];

% Cubic SVM
targetsCubicSVM128ADASYNtrain_all = [];
predsCubicSVM128ADASYNtrain_all = [];
scoresCubicSVM128ADASYNtrain_all = [];

targetsCubicSVM128ADASYNtest_all = [];
predsCubicSVM128ADASYNtest_all = [];
scoresCubicSVM128ADASYNtest_all = [];

% RBF SVM
targetsRBFSVM128ADASYNtrain_all = [];
predsRBFSVM128ADASYNtrain_all = [];
scoresRBFSVM128ADASYNtrain_all = [];

targetsRBFSVM128ADASYNtest_all = [];
predsRBFSVM128ADASYNtest_all = [];
scoresRBFSVM128ADASYNtest_all = [];

% 3kNN
targets3KNN128ADASYNtrain_all = [];
preds3KNN128ADASYNtrain_all = [];
scores3KNN128ADASYNtrain_all = [];

targets3KNN128ADASYNtest_all = [];
preds3KNN128ADASYNtest_all = [];
scores3KNN128ADASYNtest_all = [];

% 5kNN
targets5KNN128ADASYNtrain_all = [];
preds5KNN128ADASYNtrain_all = [];
scores5KNN128ADASYNtrain_all = [];

targets5KNN128ADASYNtest_all = [];
preds5KNN128ADASYNtest_all = [];
scores5KNN128ADASYNtest_all = [];

% 7 kNN
targets7KNN128ADASYNtrain_all = [];
preds7KNN128ADASYNtrain_all = [];
scores7KNN128ADASYNtrain_all = [];

targets7KNN128ADASYNtest_all = [];
preds7KNN128ADASYNtest_all = [];
scores7KNN128ADASYNtest_all = [];

% 9 kNN
targets9KNN128ADASYNtrain_all = [];
preds9KNN128ADASYNtrain_all = [];
scores9KNN128ADASYNtrain_all = [];

targets9KNN128ADASYNtest_all = [];
preds9KNN128ADASYNtest_all = [];
scores9KNN128ADASYNtest_all = [];

% RF, 5 Trees
targets5Tree128ADASYNtrain_all = [];
preds5Tree128ADASYNtrain_all = [];
scores5Tree128ADASYNtrain_all = [];

targets5Tree128ADASYNtest_all = [];
preds5Tree128ADASYNtest_all = [];
scores5Tree128ADASYNtest_all = [];

% RF, 10 Trees
targets10Tree128ADASYNtrain_all = [];
preds10Tree128ADASYNtrain_all = [];
scores10Tree128ADASYNtrain_all = [];

targets10Tree128ADASYNtest_all = [];
preds10Tree128ADASYNtest_all = [];
scores10Tree128ADASYNtest_all = [];

% RF, 20 Trees
targets20Tree128ADASYNtrain_all = [];
preds20Tree128ADASYNtrain_all = [];
scores20Tree128ADASYNtrain_all = [];

targets20Tree128ADASYNtest_all = [];
preds20Tree128ADASYNtest_all = [];
scores20Tree128ADASYNtest_all = [];

% RF, 30 Trees
targets30Tree128ADASYNtrain_all = [];
preds30Tree128ADASYNtrain_all = [];
scores30Tree128ADASYNtrain_all = [];

targets30Tree128ADASYNtest_all = [];
preds30Tree128ADASYNtest_all = [];
scores30Tree128ADASYNtest_all = [];

% RF, 40 Trees
targets40Tree128ADASYNtrain_all = [];
preds40Tree128ADASYNtrain_all = [];
scores40Tree128ADASYNtrain_all = [];

targets40Tree128ADASYNtest_all = [];
preds40Tree128ADASYNtest_all = [];
scores40Tree128ADASYNtest_all = [];

% RF, 50 Trees
targets50Tree128ADASYNtrain_all = [];
preds50Tree128ADASYNtrain_all = [];
scores50Tree128ADASYNtrain_all = [];

targets50Tree128ADASYNtest_all = [];
preds50Tree128ADASYNtest_all = [];
scores50Tree128ADASYNtest_all = [];

for i = 1:10
    test = (indices == i); 
    train = ~test;
    
    % Linear SVM
    tic
    classificationLinearSVM128ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'linear', ...
    'PolynomialOrder', [], ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);

    % Training
    [predsLinSVM128ADASYNtrain,~] = predict(classificationLinearSVM128ADASYN,trainingData(train,1:end-1));
    t1{1,i} = toc;
    targetsLinSVM128ADASYNtrain = trainingData(train,end);
    targetsLinSVM128ADASYNtrain_all = [targetsLinSVM128ADASYNtrain_all; squeeze(targetsLinSVM128ADASYNtrain)];
    predsLinSVM128ADASYNtrain_all = [predsLinSVM128ADASYNtrain_all; squeeze(predsLinSVM128ADASYNtrain)];
    
    [~,scoresLinSVM128ADASYN] = resubPredict(fitPosterior(classificationLinearSVM128ADASYN));
    scoresLinSVM128ADASYNtrain_all = [scoresLinSVM128ADASYNtrain_all;scoresLinSVM128ADASYN(:,2)];
    
    % Validation
    [predsLinSVM128ADASYNtest,scoresLinSVM128ADASYNtest] = predict(classificationLinearSVM128ADASYN,trainingData(test,1:end-1));
    targetsLinSVM128ADASYNtest = trainingData(test,end);
    targetsLinSVM128ADASYNtest_all = [targetsLinSVM128ADASYNtest_all; squeeze(targetsLinSVM128ADASYNtest)];
    predsLinSVM128ADASYNtest_all = [predsLinSVM128ADASYNtest_all; squeeze(predsLinSVM128ADASYNtest)];
    
    scoresLinSVM128ADASYNtest_all = [scoresLinSVM128ADASYNtest_all; scoresLinSVM128ADASYNtest(:,2)];
    
    
    % Quadratic SVM
    tic
    classificationQuadSVM128ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'polynomial', ...
    'PolynomialOrder', 2, ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);

    % Training
    [predsQuadSVM128ADASYNtrain,~] = predict(classificationQuadSVM128ADASYN,trainingData(train,1:end-1));
    t2{1,i} = toc;
    targetsQuadSVM128ADASYNtrain = trainingData(train,end);
    targetsQuadSVM128ADASYNtrain_all = [targetsQuadSVM128ADASYNtrain_all; squeeze(targetsQuadSVM128ADASYNtrain)];
    predsQuadSVM128ADASYNtrain_all = [predsQuadSVM128ADASYNtrain_all; squeeze(predsQuadSVM128ADASYNtrain)];
    
    [~,scoresQuadSVM128ADASYN] = resubPredict(fitPosterior(classificationQuadSVM128ADASYN));
    scoresQuadSVM128ADASYNtrain_all = [scoresQuadSVM128ADASYNtrain_all; scoresQuadSVM128ADASYN(:,2)];
    
    % Validation
    [predsQuadSVM128ADASYNtest,scoresQuadSVM128ADASYNtest] = predict(classificationQuadSVM128ADASYN,trainingData(test,1:end-1));
    targetsQuadSVM128ADASYNtest = trainingData(test,end);
    targetsQuadSVM128ADASYNtest_all = [targetsQuadSVM128ADASYNtest_all; squeeze(targetsQuadSVM128ADASYNtest)];
    predsQuadSVM128ADASYNtest_all = [predsQuadSVM128ADASYNtest_all; squeeze(predsQuadSVM128ADASYNtest)];
    
    scoresQuadSVM128ADASYNtest_all = [scoresQuadSVM128ADASYNtest_all; scoresQuadSVM128ADASYNtest(:,2)];
    
    
    % Cubic SVM
    tic
    classificationCubicSVM128ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'polynomial', ...
    'PolynomialOrder', 3, ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);

    % Training
    [predsCubicSVM128ADASYNtrain,~] = predict(classificationCubicSVM128ADASYN,trainingData(train,1:end-1));
    t3{1,i} = toc;
    targetsCubicSVM128ADASYNtrain = trainingData(train,end);
    targetsCubicSVM128ADASYNtrain_all = [targetsCubicSVM128ADASYNtrain_all; squeeze(targetsCubicSVM128ADASYNtrain)];
    predsCubicSVM128ADASYNtrain_all = [predsCubicSVM128ADASYNtrain_all; squeeze(predsCubicSVM128ADASYNtrain)];
    
    [~,scoresCubicSVM128ADASYN] = resubPredict(fitPosterior(classificationCubicSVM128ADASYN));
    scoresCubicSVM128ADASYNtrain_all = [scoresCubicSVM128ADASYNtrain_all; scoresCubicSVM128ADASYN(:,2)];    
    
    % Validation
    [predsCubicSVM128ADASYNtest,scoresCubicSVM128ADASYNtest] = predict(classificationCubicSVM128ADASYN,trainingData(test,1:end-1));
    targetsCubicSVM128ADASYNtest = trainingData(test,end);
    targetsCubicSVM128ADASYNtest_all = [targetsCubicSVM128ADASYNtest_all; squeeze(targetsCubicSVM128ADASYNtest)];
    predsCubicSVM128ADASYNtest_all = [predsCubicSVM128ADASYNtest_all; squeeze(predsCubicSVM128ADASYNtest)];
    
    scoresCubicSVM128ADASYNtest_all = [scoresCubicSVM128ADASYNtest_all; scoresCubicSVM128ADASYNtest(:,2)];
    
    
    % RBF SVM
    tic
    classificationRBFSVM128ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'RBF', ...
    'PolynomialOrder', [], ...
    'KernelScale', 'auto', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);
    
    % Training
    [predsRBFSVM128ADASYNtrain,~] = predict(classificationRBFSVM128ADASYN,trainingData(train,1:end-1));
    t4{1,i} = toc;
    targetsRBFSVM128ADASYNtrain = trainingData(train,end);
    targetsRBFSVM128ADASYNtrain_all = [targetsRBFSVM128ADASYNtrain_all; squeeze(targetsRBFSVM128ADASYNtrain)];
    predsRBFSVM128ADASYNtrain_all = [predsRBFSVM128ADASYNtrain_all; squeeze(predsRBFSVM128ADASYNtrain)];
    
    [~,scoresRBFSVM128ADASYN] = resubPredict(fitPosterior(classificationRBFSVM128ADASYN));
    scoresRBFSVM128ADASYNtrain_all = [scoresRBFSVM128ADASYNtrain_all; scoresRBFSVM128ADASYN(:,2)];    
    
    % Validation
    [predsRBFSVM128ADASYNtest,scoresRBFSVM128ADASYNtest] = predict(classificationRBFSVM128ADASYN,trainingData(test,1:end-1));
    targetsRBFSVM128ADASYNtest = trainingData(test,end);
    targetsRBFSVM128ADASYNtest_all = [targetsRBFSVM128ADASYNtest_all; squeeze(targetsRBFSVM128ADASYNtest)];
    predsRBFSVM128ADASYNtest_all = [predsRBFSVM128ADASYNtest_all; squeeze(predsRBFSVM128ADASYNtest)];
    
    scoresRBFSVM128ADASYNtest_all = [scoresRBFSVM128ADASYNtest_all; scoresRBFSVM128ADASYNtest(:,2)];
    
    
    % kNN, 3 neighbors
    tic
    classification3KNN128ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 3, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds3KNN128ADASYNtrain,~] = predict(classification3KNN128ADASYN,trainingData(train,1:end-1));
    t5{1,i} = toc;
    targets3KNN128ADASYNtrain = trainingData(train,end);
    targets3KNN128ADASYNtrain_all = [targets3KNN128ADASYNtrain_all; squeeze(targets3KNN128ADASYNtrain)];
    preds3KNN128ADASYNtrain_all = [preds3KNN128ADASYNtrain_all; squeeze(preds3KNN128ADASYNtrain)];
    
    [~,scores3KNN128ADASYN] = resubPredict(classification3KNN128ADASYN);
    scores3KNN128ADASYNtrain_all = [scores3KNN128ADASYNtrain_all; scores3KNN128ADASYN(:,2)];    
    
    % Validation
    [preds3KNN128ADASYNtest,scores3KNN128ADASYNtest] = predict(classification3KNN128ADASYN,trainingData(test,1:end-1));
    targets3KNN128ADASYNtest = trainingData(test,end);
    targets3KNN128ADASYNtest_all = [targets3KNN128ADASYNtest_all; squeeze(targets3KNN128ADASYNtest)];
    preds3KNN128ADASYNtest_all = [preds3KNN128ADASYNtest_all; squeeze(preds3KNN128ADASYNtest)];
    
    scores3KNN128ADASYNtest_all = [scores3KNN128ADASYNtest_all; scores3KNN128ADASYNtest(:,2)];
    
    
    % kNN, 5 neighbors
    tic
    classification5KNN128ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 5, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds5KNN128ADASYNtrain,~] = predict(classification5KNN128ADASYN,trainingData(train,1:end-1));
    t6{1,i} = toc;
    targets5KNN128ADASYNtrain = trainingData(train,end);
    targets5KNN128ADASYNtrain_all = [targets5KNN128ADASYNtrain_all; squeeze(targets5KNN128ADASYNtrain)];
    preds5KNN128ADASYNtrain_all = [preds5KNN128ADASYNtrain_all; squeeze(preds5KNN128ADASYNtrain)];
    
    [~,scores5KNN128ADASYN] = resubPredict(classification5KNN128ADASYN);
    scores5KNN128ADASYNtrain_all = [scores5KNN128ADASYNtrain_all; scores5KNN128ADASYN(:,2)];    
    
    % Validation
    [preds5KNN128ADASYNtest,scores5KNN128ADASYNtest] = predict(classification5KNN128ADASYN,trainingData(test,1:end-1));
    targets5KNN128ADASYNtest = trainingData(test,end);
    targets5KNN128ADASYNtest_all = [targets5KNN128ADASYNtest_all; squeeze(targets5KNN128ADASYNtest)];
    preds5KNN128ADASYNtest_all = [preds5KNN128ADASYNtest_all; squeeze(preds5KNN128ADASYNtest)];
    
    scores5KNN128ADASYNtest_all = [scores5KNN128ADASYNtest_all; scores5KNN128ADASYNtest(:,2)];
    
    
    % kNN, 7 neighbors
    tic
    classification7KNN128ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 7, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds7KNN128ADASYNtrain,~] = predict(classification7KNN128ADASYN,trainingData(train,1:end-1));
    t7{1,i} = toc;
    targets7KNN128ADASYNtrain = trainingData(train,end);
    targets7KNN128ADASYNtrain_all = [targets7KNN128ADASYNtrain_all; squeeze(targets7KNN128ADASYNtrain)];
    preds7KNN128ADASYNtrain_all = [preds7KNN128ADASYNtrain_all; squeeze(preds7KNN128ADASYNtrain)];
    
    [~,scores7KNN128ADASYN] = resubPredict(classification7KNN128ADASYN);
    scores7KNN128ADASYNtrain_all = [scores7KNN128ADASYNtrain_all; scores7KNN128ADASYN(:,2)];    
    
    % Validation
    [preds7KNN128ADASYNtest,scores7KNN128ADASYNtest] = predict(classification7KNN128ADASYN,trainingData(test,1:end-1));
    targets7KNN128ADASYNtest = trainingData(test,end);
    targets7KNN128ADASYNtest_all = [targets7KNN128ADASYNtest_all; squeeze(targets7KNN128ADASYNtest)];
    preds7KNN128ADASYNtest_all = [preds7KNN128ADASYNtest_all; squeeze(preds7KNN128ADASYNtest)];
    
    scores7KNN128ADASYNtest_all = [scores7KNN128ADASYNtest_all; scores7KNN128ADASYNtest(:,2)];
    
    
    % kNN, 9 neighbors
    tic
    classification9KNN128ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 9, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds9KNN128ADASYNtrain,~] = predict(classification9KNN128ADASYN,trainingData(train,1:end-1));
    t8{1,i} = toc;
    targets9KNN128ADASYNtrain = trainingData(train,end);
    targets9KNN128ADASYNtrain_all = [targets9KNN128ADASYNtrain_all; squeeze(targets9KNN128ADASYNtrain)];
    preds9KNN128ADASYNtrain_all = [preds9KNN128ADASYNtrain_all; squeeze(preds9KNN128ADASYNtrain)];
    
    [~,scores9KNN128ADASYN] = resubPredict(classification9KNN128ADASYN);
    scores9KNN128ADASYNtrain_all = [scores9KNN128ADASYNtrain_all; scores9KNN128ADASYN(:,2)];    
    
    % Validation
    [preds9KNN128ADASYNtest,scores9KNN128ADASYNtest] = predict(classification9KNN128ADASYN,trainingData(test,1:end-1));
    targets9KNN128ADASYNtest = trainingData(test,end);
    targets9KNN128ADASYNtest_all = [targets9KNN128ADASYNtest_all; squeeze(targets9KNN128ADASYNtest)];
    preds9KNN128ADASYNtest_all = [preds9KNN128ADASYNtest_all; squeeze(preds9KNN128ADASYNtest)];
    
    scores9KNN128ADASYNtest_all = [scores9KNN128ADASYNtest_all; scores9KNN128ADASYNtest(:,2)];
    
    
    % RF, 5 Trees
    tic
    classification5Tree128ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 5, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds5Tree128ADASYNtrain,~] = predict(classification5Tree128ADASYN,trainingData(train,1:end-1));
    t9{1,i} = toc;
    targets5Tree128ADASYNtrain = trainingData(train,end);
    targets5Tree128ADASYNtrain_all = [targets5Tree128ADASYNtrain_all; squeeze(targets5Tree128ADASYNtrain)];
    preds5Tree128ADASYNtrain_all = [preds5Tree128ADASYNtrain_all; squeeze(preds5Tree128ADASYNtrain)];
    
    [~,scores5Tree128ADASYN] = resubPredict(classification5Tree128ADASYN);
    scores5Tree128ADASYNtrain_all = [scores5Tree128ADASYNtrain_all; scores5Tree128ADASYN(:,2)];    
    
    % Validation
    [preds5Tree128ADASYNtest,scores5Tree128ADASYNtest] = predict(classification5Tree128ADASYN,trainingData(test,1:end-1));
    targets5Tree128ADASYNtest = trainingData(test,end);
    targets5Tree128ADASYNtest_all = [targets5Tree128ADASYNtest_all; squeeze(targets5Tree128ADASYNtest)];
    preds5Tree128ADASYNtest_all = [preds5Tree128ADASYNtest_all; squeeze(preds5Tree128ADASYNtest)];
    
    scores5Tree128ADASYNtest_all = [scores5Tree128ADASYNtest_all; scores5Tree128ADASYNtest(:,2)];
    
    
    
    % RF, 10 Trees
    tic
    classification10Tree128ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 10, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds10Tree128ADASYNtrain,~] = predict(classification10Tree128ADASYN,trainingData(train,1:end-1));
    t10{1,i} = toc;
    targets10Tree128ADASYNtrain = trainingData(train,end);
    targets10Tree128ADASYNtrain_all = [targets10Tree128ADASYNtrain_all; squeeze(targets10Tree128ADASYNtrain)];
    preds10Tree128ADASYNtrain_all = [preds10Tree128ADASYNtrain_all; squeeze(preds10Tree128ADASYNtrain)];
    
    [~,scores10Tree128ADASYN] = resubPredict(classification10Tree128ADASYN);
    scores10Tree128ADASYNtrain_all = [scores10Tree128ADASYNtrain_all; scores10Tree128ADASYN(:,2)];      
    
    % Validation
    [preds10Tree128ADASYNtest,scores10Tree128ADASYNtest] = predict(classification10Tree128ADASYN,trainingData(test,1:end-1));
    targets10Tree128ADASYNtest = trainingData(test,end);
    targets10Tree128ADASYNtest_all = [targets10Tree128ADASYNtest_all; squeeze(targets10Tree128ADASYNtest)];
    preds10Tree128ADASYNtest_all = [preds10Tree128ADASYNtest_all; squeeze(preds10Tree128ADASYNtest)];
    
    scores10Tree128ADASYNtest_all = [scores10Tree128ADASYNtest_all; scores10Tree128ADASYNtest(:,2)];
    
    
    
    % RF, 20 Trees
    tic
    classification20Tree128ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 20, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds20Tree128ADASYNtrain,~] = predict(classification20Tree128ADASYN,trainingData(train,1:end-1));
    t11{1,i} = toc;
    targets20Tree128ADASYNtrain = trainingData(train,end);
    targets20Tree128ADASYNtrain_all = [targets20Tree128ADASYNtrain_all; squeeze(targets20Tree128ADASYNtrain)];
    preds20Tree128ADASYNtrain_all = [preds20Tree128ADASYNtrain_all; squeeze(preds20Tree128ADASYNtrain)];
    
    [~,scores20Tree128ADASYN] = resubPredict(classification20Tree128ADASYN);
    scores20Tree128ADASYNtrain_all = [scores20Tree128ADASYNtrain_all; scores20Tree128ADASYN(:,2)];    
    
    % Validation
    [preds20Tree128ADASYNtest,scores20Tree128ADASYNtest] = predict(classification20Tree128ADASYN,trainingData(test,1:end-1));
    targets20Tree128ADASYNtest = trainingData(test,end);
    targets20Tree128ADASYNtest_all = [targets20Tree128ADASYNtest_all; squeeze(targets20Tree128ADASYNtest)];
    preds20Tree128ADASYNtest_all = [preds20Tree128ADASYNtest_all; squeeze(preds20Tree128ADASYNtest)];
    
    scores20Tree128ADASYNtest_all = [scores20Tree128ADASYNtest_all; scores20Tree128ADASYNtest(:,2)]; 
    
    
    % RF, 30 Trees
    tic
    classification30Tree128ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 30, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds30Tree128ADASYNtrain,~] = predict(classification30Tree128ADASYN,trainingData(train,1:end-1));
    t12{1,i} = toc;
    targets30Tree128ADASYNtrain = trainingData(train,end);
    targets30Tree128ADASYNtrain_all = [targets30Tree128ADASYNtrain_all; squeeze(targets30Tree128ADASYNtrain)];
    preds30Tree128ADASYNtrain_all = [preds30Tree128ADASYNtrain_all; squeeze(preds30Tree128ADASYNtrain)];
    
    [~,scores30Tree128ADASYN] = resubPredict(classification30Tree128ADASYN);
    scores30Tree128ADASYNtrain_all = [scores30Tree128ADASYNtrain_all; scores30Tree128ADASYN(:,2)];    
    
    % Validation
    [preds30Tree128ADASYNtest,scores30Tree128ADASYNtest] = predict(classification30Tree128ADASYN,trainingData(test,1:end-1));
    targets30Tree128ADASYNtest = trainingData(test,end);
    targets30Tree128ADASYNtest_all = [targets30Tree128ADASYNtest_all; squeeze(targets30Tree128ADASYNtest)];
    preds30Tree128ADASYNtest_all = [preds30Tree128ADASYNtest_all; squeeze(preds30Tree128ADASYNtest)];
    
    scores30Tree128ADASYNtest_all = [scores30Tree128ADASYNtest_all; scores30Tree128ADASYNtest(:,2)];
    
    
    % RF, 40 Trees
    tic
    classification40Tree128ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 40, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds40Tree128ADASYNtrain,~] = predict(classification40Tree128ADASYN,trainingData(train,1:end-1));
    t13{1,i} = toc;
    targets40Tree128ADASYNtrain = trainingData(train,end);
    targets40Tree128ADASYNtrain_all = [targets40Tree128ADASYNtrain_all; squeeze(targets40Tree128ADASYNtrain)];
    preds40Tree128ADASYNtrain_all = [preds40Tree128ADASYNtrain_all; squeeze(preds40Tree128ADASYNtrain)];
    
    [~,scores40Tree128ADASYN] = resubPredict(classification40Tree128ADASYN);
    scores40Tree128ADASYNtrain_all = [scores40Tree128ADASYNtrain_all; scores40Tree128ADASYN(:,2)];    
    
    % Validation
    [preds40Tree128ADASYNtest,scores40Tree128ADASYNtest] = predict(classification40Tree128ADASYN,trainingData(test,1:end-1));
    targets40Tree128ADASYNtest = trainingData(test,end);
    targets40Tree128ADASYNtest_all = [targets40Tree128ADASYNtest_all; squeeze(targets40Tree128ADASYNtest)];
    preds40Tree128ADASYNtest_all = [preds40Tree128ADASYNtest_all; squeeze(preds40Tree128ADASYNtest)];
    
    scores40Tree128ADASYNtest_all = [scores40Tree128ADASYNtest_all; scores40Tree128ADASYNtest(:,2)];
    
    
    % RF, 50 Trees
    tic
    classification50Tree128ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 50, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds50Tree128ADASYNtrain,~] = predict(classification50Tree128ADASYN,trainingData(train,1:end-1));
    t14{1,i} = toc;
    targets50Tree128ADASYNtrain = trainingData(train,end);
    targets50Tree128ADASYNtrain_all = [targets50Tree128ADASYNtrain_all; squeeze(targets50Tree128ADASYNtrain)];
    preds50Tree128ADASYNtrain_all = [preds50Tree128ADASYNtrain_all; squeeze(preds50Tree128ADASYNtrain)];
    
    [~,scores50Tree128ADASYN] = resubPredict(classification50Tree128ADASYN);
    scores50Tree128ADASYNtrain_all = [scores50Tree128ADASYNtrain_all; scores50Tree128ADASYN(:,2)];    
    
    % Validation
    [preds50Tree128ADASYNtest,scores50Tree128ADASYNtest] = predict(classification50Tree128ADASYN,trainingData(test,1:end-1));
    targets50Tree128ADASYNtest = trainingData(test,end);
    targets50Tree128ADASYNtest_all = [targets50Tree128ADASYNtest_all; squeeze(targets50Tree128ADASYNtest)];
    preds50Tree128ADASYNtest_all = [preds50Tree128ADASYNtest_all; squeeze(preds50Tree128ADASYNtest)];
    
    scores50Tree128ADASYNtest_all = [scores50Tree128ADASYNtest_all; scores50Tree128ADASYNtest(:,2)];
end

save('classificationLinearSVM128ADASYN.mat','classificationLinearSVM128ADASYN','-v7.3'); % majority voting
%save('classificationLinearSVM128ADASYN_30.mat','classificationLinearSVM128ADASYN','-v7.3'); % Threshold 30%
%save('classificationLinearSVM128ADASYN_20.mat','classificationLinearSVM128ADASYN','-v7.3'); % Threshold 20%
%save('classificationLinearSVM128ADASYN_10.mat','classificationLinearSVM128ADASYN','-v7.3'); % Threshold 10%

save('classificationQuadSVM128ADASYN.mat','classificationQuadSVM128ADASYN','-v7.3'); % majority voting
%save('classificationQuadSVM128ADASYN_30.mat','classificationQuadSVM128ADASYN','-v7.3'); % Threshold 30%
%save('classificationQuadSVM128ADASYN_20.mat','classificationQuadSVM128ADASYN','-v7.3'); % Threshold 20%
%save('classificationQuadSVM128ADASYN_10.mat','classificationQuadSVM128ADASYN','-v7.3'); % Threshold 10%

save('classificationCubicSVM128ADASYN.mat','classificationCubicSVM128ADASYN','-v7.3'); % majority voting
%save('classificationCubicSVM128ADASYN_30.mat','classificationCubicSVM128ADASYN','-v7.3'); % Threshold 30%
%save('classificationCubicSVM128ADASYN_20.mat','classificationCubicSVM128ADASYN','-v7.3'); % Threshold 20%
%save('classificationCubicSVM128ADASYN_10.mat','classificationCubicSVM128ADASYN','-v7.3'); % Threshold 10%

save('classificationRBFSVM128ADASYN.mat','classificationRBFSVM128ADASYN','-v7.3'); % majority voting
%save('classificationRBFSVM128ADASYN_30.mat','classificationRBFSVM128ADASYN','-v7.3'); % Threshold 30%
%save('classificationRBFSVM128ADASYN_20.mat','classificationRBFSVM128ADASYN','-v7.3'); % Threshold 20%
%save('classificationRBFSVM128ADASYN_10.mat','classificationRBFSVM128ADASYN','-v7.3'); % Threshold 10%

save('classification3KNN128ADASYN.mat','classification3KNN128ADASYN','-v7.3'); % majority voting
%save('classification3KNN128ADASYN_30.mat','classification3KNN128ADASYN','-v7.3'); % Threshold 30%
%save('classification3KNN128ADASYN_20.mat','classification3KNN128ADASYN','-v7.3'); % Threshold 20%
%save('classification3KNN128ADASYN_10.mat','classification3KNN128ADASYN','-v7.3'); % Threshold 10%

save('classification5KNN128ADASYN.mat','classification5KNN128ADASYN','-v7.3'); % majority voting
%save('classification5KNN128ADASYN_30.mat','classification5KNN128ADASYN','-v7.3'); % Threshold 30%
%save('classification5KNN128ADASYN_20.mat','classification5KNN128ADASYN','-v7.3'); % Threshold 20%
%save('classification5KNN128ADASYN_10.mat','classification5KNN128ADASYN','-v7.3'); % Threshold 10%

save('classification7KNN128ADASYN.mat','classification7KNN128ADASYN','-v7.3'); % majority voting
%save('classification7KNN128ADASYN_30.mat','classification7KNN128ADASYN','-v7.3'); % Threshold 30%
%save('classification7KNN128ADASYN_20.mat','classification7KNN128ADASYN','-v7.3'); % Threshold 20%
%save('classification7KNN128ADASYN_10.mat','classification7KNN128ADASYN','-v7.3'); % Threshold 10%

save('classification9KNN128ADASYN.mat','classification9KNN128ADASYN','-v7.3'); % majority voting
%save('classification9KNN128ADASYN_30.mat','classification9KNN128ADASYN','-v7.3'); % Threshold 30%
%save('classification9KNN128ADASYN_20.mat','classification9KNN128ADASYN','-v7.3'); % Threshold 20%
%save('classification9KNN128ADASYN_10.mat','classification9KNN128ADASYN','-v7.3'); % Threshold 10%

save('classification5Tree128ADASYN.mat','classification5Tree128ADASYN','-v7.3'); % majority voting
%save('classification5Tree128ADASYN_30.mat','classification5Tree128ADASYN','-v7.3'); % Threshold 30%
%save('classification5Tree128ADASYN_20.mat','classification5Tree128ADASYN','-v7.3'); % Threshold 20%
%save('classification5Tree128ADASYN_10.mat','classification5Tree128ADASYN','-v7.3'); % Threshold 10%

save('classification10Tree128ADASYN.mat','classification10Tree128ADASYN','-v7.3'); % majority voting
%save('classification10Tree128ADASYN_30.mat','classification10Tree128ADASYN','-v7.3'); % Threshold 30%
%save('classification10Tree128ADASYN_20.mat','classification10Tree128ADASYN','-v7.3'); % Threshold 20%
%save('classification10Tree128ADASYN_10.mat','classification10Tree128ADASYN','-v7.3'); % Threshold 10%

save('classification20Tree128ADASYN.mat','classification20Tree128ADASYN','-v7.3'); % majority voting
%save('classification20Tree128ADASYN_30.mat','classification20Tree128ADASYN','-v7.3'); % Threshold 30%
%save('classification20Tree128ADASYN_20.mat','classification20Tree128ADASYN','-v7.3'); % Threshold 20%
%save('classification20Tree128ADASYN_10.mat','classification20Tree128ADASYN','-v7.3'); % Threshold 10%

save('classification30Tree128ADASYN.mat','classification30Tree128ADASYN','-v7.3'); % majority voting
%save('classification30Tree128ADASYN_30.mat','classification30Tree128ADASYN','-v7.3'); % Threshold 30%
%save('classification30Tree128ADASYN_20.mat','classification30Tree128ADASYN','-v7.3'); % Threshold 20%
%save('classification30Tree128ADASYN_10.mat','classification30Tree128ADASYN','-v7.3'); % Threshold 10%

save('classification40Tree128ADASYN.mat','classification40Tree128ADASYN','-v7.3'); % majority voting
%save('classification40Tree128ADASYN_30.mat','classification40Tree128ADASYN','-v7.3'); % Threshold 30%
%save('classification40Tree128ADASYN_20.mat','classification40Tree128ADASYN','-v7.3'); % Threshold 20%
%save('classification40Tree128ADASYN_10.mat','classification40Tree128ADASYN','-v7.3'); % Threshold 10%

save('classification50Tree128ADASYN.mat','classification50Tree128ADASYN','-v7.3'); % majority voting
%save('classification50Tree128ADASYN_30.mat','classification50Tree128ADASYN','-v7.3'); % Threshold 30%
%save('classification50Tree128ADASYN_20.mat','classification50Tree128ADASYN','-v7.3'); % Threshold 20%
%save('classification50Tree128ADASYN_10.mat','classification50Tree128ADASYN','-v7.3'); % Threshold 10%


m1 = mean([t1{:}]);
m2 = mean([t2{:}]);
m3 = mean([t3{:}]);
m4 = mean([t4{:}]);
m5 = mean([t5{:}]);
m6 = mean([t6{:}]);
m7 = mean([t7{:}]);
m8 = mean([t8{:}]);
m9 = mean([t9{:}]);
m10 = mean([t10{:}]);
m11 = mean([t11{:}]);
m12 = mean([t12{:}]);
m13 = mean([t13{:}]);
m14 = mean([t14{:}]);

s1 = sum([t1{:}]);
s2 = sum([t2{:}]);
s3 = sum([t3{:}]);
s4 = sum([t4{:}]);
s5 = sum([t5{:}]);
s6 = sum([t6{:}]);
s7 = sum([t7{:}]);
s8 = sum([t8{:}]);
s9 = sum([t9{:}]);
s10 = sum([t10{:}]);
s11 = sum([t11{:}]);
s12 = sum([t12{:}]);
s13 = sum([t13{:}]);
s14 = sum([t14{:}]);




% Linear SVM
[xLinSVM128ADASYNtrain,yLinSVM128ADASYNtrain,~,aucLinSVM128ADASYNtrain] = perfcurve(targetsLinSVM128ADASYNtrain_all,scoresLinSVM128ADASYNtrain_all,1);
[xLinSVM128ADASYNtest,yLinSVM128ADASYNtest,~,aucLinSVM128ADASYNtest] = perfcurve(targetsLinSVM128ADASYNtest_all,scoresLinSVM128ADASYNtest_all,1);

% Quadratic SVM
[xQuadSVM128ADASYNtrain,yQuadSVM128ADASYNtrain,~,aucQuadSVM128ADASYNtrain] = perfcurve(targetsQuadSVM128ADASYNtrain_all,scoresQuadSVM128ADASYNtrain_all,1);
[xQuadSVM128ADASYNtest,yQuadSVM128ADASYNtest,~,aucQuadSVM128ADASYNtest] = perfcurve(targetsQuadSVM128ADASYNtest_all,scoresQuadSVM128ADASYNtest_all,1);

% Cubic SVM
[xCubicSVM128ADASYNtrain,yCubicSVM128ADASYNtrain,~,aucCubicSVM128ADASYNtrain] = perfcurve(targetsCubicSVM128ADASYNtrain_all,scoresCubicSVM128ADASYNtrain_all,1);
[xCubicSVM128ADASYNtest,yCubicSVM128ADASYNtest,~,aucCubicSVM128ADASYNtest] = perfcurve(targetsCubicSVM128ADASYNtest_all,scoresCubicSVM128ADASYNtest_all,1);

% RBF SVM
[xRBFSVM128ADASYNtrain,yRBFSVM128ADASYNtrain,~,aucRBFSVM128ADASYNtrain] = perfcurve(targetsRBFSVM128ADASYNtrain_all,scoresRBFSVM128ADASYNtrain_all,1);
[xRBFSVM128ADASYNtest,yRBFSVM128ADASYNtest,~,aucRBFSVM128ADASYNtest] = perfcurve(targetsRBFSVM128ADASYNtest_all,scoresRBFSVM128ADASYNtest_all,1);

% kNN, 3 neighbors
[x3KNN128ADASYNtrain,y3KNN128ADASYNtrain,~,auc3KNN128ADASYNtrain] = perfcurve(targets3KNN128ADASYNtrain_all,scores3KNN128ADASYNtrain_all,1);
[x3KNN128ADASYNtest,y3KNN128ADASYNtest,~,auc3KNN128ADASYNtest] = perfcurve(targets3KNN128ADASYNtest_all,scores3KNN128ADASYNtest_all,1);

% kNN, 5 neighbors
[x5KNN128ADASYNtrain,y5KNN128ADASYNtrain,~,auc5KNN128ADASYNtrain] = perfcurve(targets5KNN128ADASYNtrain_all,scores5KNN128ADASYNtrain_all,1);
[x5KNN128ADASYNtest,y5KNN128ADASYNtest,~,auc5KNN128ADASYNtest] = perfcurve(targets5KNN128ADASYNtest_all,scores5KNN128ADASYNtest_all,1);

% kNN, 7 neighbors
[x7KNN128ADASYNtrain,y7KNN128ADASYNtrain,~,auc7KNN128ADASYNtrain] = perfcurve(targets7KNN128ADASYNtrain_all,scores7KNN128ADASYNtrain_all,1);
[x7KNN128ADASYNtest,y7KNN128ADASYNtest,~,auc7KNN128ADASYNtest] = perfcurve(targets7KNN128ADASYNtest_all,scores7KNN128ADASYNtest_all,1);

% kNN, 9 neighbors
[x9KNN128ADASYNtrain,y9KNN128ADASYNtrain,~,auc9KNN128ADASYNtrain] = perfcurve(targets9KNN128ADASYNtrain_all,scores9KNN128ADASYNtrain_all,1);
[x9KNN128ADASYNtest,y9KNN128ADASYNtest,~,auc9KNN128ADASYNtest] = perfcurve(targets9KNN128ADASYNtest_all,scores9KNN128ADASYNtest_all,1);

% RF, 5 Trees
[x5Tree128ADASYNtrain,y5Tree128ADASYNtrain,~,auc5Tree128ADASYNtrain] = perfcurve(targets5Tree128ADASYNtrain_all,scores5Tree128ADASYNtrain_all,1);
[x5Tree128ADASYNtest,y5Tree128ADASYNtest,~,auc5Tree128ADASYNtest] = perfcurve(targets5Tree128ADASYNtest_all,scores5Tree128ADASYNtest_all,1);

% RF, 10 Trees
[x10Tree128ADASYNtrain,y10Tree128ADASYNtrain,~,auc10Tree128ADASYNtrain] = perfcurve(targets10Tree128ADASYNtrain_all,scores10Tree128ADASYNtrain_all,1);
[x10Tree128ADASYNtest,y10Tree128ADASYNtest,~,auc10Tree128ADASYNtest] = perfcurve(targets10Tree128ADASYNtest_all,scores10Tree128ADASYNtest_all,1);

% RF, 20 Trees
[x20Tree128ADASYNtrain,y20Tree128ADASYNtrain,~,auc20Tree128ADASYNtrain] = perfcurve(targets20Tree128ADASYNtrain_all,scores20Tree128ADASYNtrain_all,1);
[x20Tree128ADASYNtest,y20Tree128ADASYNtest,~,auc20Tree128ADASYNtest] = perfcurve(targets20Tree128ADASYNtest_all,scores20Tree128ADASYNtest_all,1);

% RF, 30 Trees
[x30Tree128ADASYNtrain,y30Tree128ADASYNtrain,~,auc30Tree128ADASYNtrain] = perfcurve(targets30Tree128ADASYNtrain_all,scores30Tree128ADASYNtrain_all,1);
[x30Tree128ADASYNtest,y30Tree128ADASYNtest,~,auc30Tree128ADASYNtest] = perfcurve(targets30Tree128ADASYNtest_all,scores30Tree128ADASYNtest_all,1);

% RF, 40 Trees
[x40Tree128ADASYNtrain,y40Tree128ADASYNtrain,~,auc40Tree128ADASYNtrain] = perfcurve(targets40Tree128ADASYNtrain_all,scores40Tree128ADASYNtrain_all,1);
[x40Tree128ADASYNtest,y40Tree128ADASYNtest,~,auc40Tree128ADASYNtest] = perfcurve(targets40Tree128ADASYNtest_all,scores40Tree128ADASYNtest_all,1);

% RF, 50 Trees
[x50Tree128ADASYNtrain,y50Tree128ADASYNtrain,~,auc50Tree128ADASYNtrain] = perfcurve(targets50Tree128ADASYNtrain_all,scores50Tree128ADASYNtrain_all,1);
[x50Tree128ADASYNtest,y50Tree128ADASYNtest,~,auc50Tree128ADASYNtest] = perfcurve(targets50Tree128ADASYNtest_all,scores50Tree128ADASYNtest_all,1);

% Confusion matrices
figure()
subplot(121)
confusionchart(targetsLinSVM128ADASYNtrain_all,predsLinSVM128ADASYNtrain_all);
title('Linear SVM, training')
subplot(122)
confusionchart(targetsLinSVM128ADASYNtest_all,predsLinSVM128ADASYNtest_all);
title('Linear SVM, validation')

figure()
subplot(121)
confusionchart(targetsQuadSVM128ADASYNtrain_all,predsQuadSVM128ADASYNtrain_all);
title('Quadratic SVM, training')
subplot(122)
confusionchart(targetsQuadSVM128ADASYNtest_all,predsQuadSVM128ADASYNtest_all);
title('Quadratic SVM, validation')

figure()
subplot(121)
confusionchart(targetsCubicSVM128ADASYNtrain_all,predsCubicSVM128ADASYNtrain_all);
title('Cubic SVM, training')
subplot(122)
confusionchart(targetsCubicSVM128ADASYNtest_all,predsCubicSVM128ADASYNtest_all);
title('Cubic SVM, validation')

figure()
subplot(121)
confusionchart(targetsRBFSVM128ADASYNtrain_all,predsRBFSVM128ADASYNtrain_all);
title('RBF SVM, training')
subplot(122)
confusionchart(targetsRBFSVM128ADASYNtest_all,predsRBFSVM128ADASYNtest_all);
title('RBF SVM, validation')

figure()
subplot(121)
confusionchart(targets3KNN128ADASYNtrain_all,preds3KNN128ADASYNtrain_all);
title('kNN - k = 3, training')
subplot(122)
confusionchart(targets3KNN128ADASYNtest_all,preds3KNN128ADASYNtest_all);
title('kNN - k = 3, validation')

figure()
subplot(121)
confusionchart(targets5KNN128ADASYNtrain_all,preds5KNN128ADASYNtrain_all);
title('kNN - k = 5, training')
subplot(122)
confusionchart(targets5KNN128ADASYNtest_all,preds5KNN128ADASYNtest_all);
title('kNN - k = 5, validation')

figure()
subplot(121)
confusionchart(targets7KNN128ADASYNtrain_all,preds7KNN128ADASYNtrain_all);
title('kNN - k = 7, training')
subplot(122)
confusionchart(targets7KNN128ADASYNtest_all,preds7KNN128ADASYNtest_all);
title('kNN - k = 7, validation')

figure()
subplot(121)
confusionchart(targets9KNN128ADASYNtrain_all,preds9KNN128ADASYNtrain_all);
title('kNN - k = 9, training')
subplot(122)
confusionchart(targets9KNN128ADASYNtest_all,preds9KNN128ADASYNtest_all);
title('kNN - k = 9, validation')

figure()
subplot(121)
confusionchart(targets5Tree128ADASYNtrain_all,preds5Tree128ADASYNtrain_all);
title('RF 5 Trees, training')
subplot(122)
confusionchart(targets5Tree128ADASYNtest_all,preds5Tree128ADASYNtest_all);
title('RF 5 Trees, validation')

figure()
subplot(121)
confusionchart(targets10Tree128ADASYNtrain_all,preds10Tree128ADASYNtrain_all);
title('RF 10 Trees, training')
subplot(122)
confusionchart(targets10Tree128ADASYNtest_all,preds10Tree128ADASYNtest_all);
title('RF 10 Trees, validation')

figure()
subplot(121)
confusionchart(targets20Tree128ADASYNtrain_all,preds20Tree128ADASYNtrain_all);
title('RF 20 Trees, training')
subplot(122)
confusionchart(targets20Tree128ADASYNtest_all,preds20Tree128ADASYNtest_all);
title('RF 20 Trees, validation')

figure()
subplot(121)
confusionchart(targets30Tree128ADASYNtrain_all,preds30Tree128ADASYNtrain_all);
title('RF 30 Trees, training')
subplot(122)
confusionchart(targets30Tree128ADASYNtest_all,preds30Tree128ADASYNtest_all);
title('RF 30 Trees, validation')

figure()
subplot(121)
confusionchart(targets40Tree128ADASYNtrain_all,preds40Tree128ADASYNtrain_all);
title('RF 40 Trees, training')
subplot(122)
confusionchart(targets40Tree128ADASYNtest_all,preds40Tree128ADASYNtest_all);
title('RF 40 Trees, validation')

figure()
subplot(121)
confusionchart(targets50Tree128ADASYNtrain_all,preds50Tree128ADASYNtrain_all);
title('RF 50 Trees, training')
subplot(122)
confusionchart(targets50Tree128ADASYNtest_all,preds50Tree128ADASYNtest_all);
title('RF 50 Trees, validation')


% % ROC curve plots, training and validation
figure()
plot(xLinSVM128ADASYNtrain,yLinSVM128ADASYNtrain,'LineWidth',2)
hold on
plot(xLinSVM128ADASYNtest,yLinSVM128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, Linear SVM')
legend('Training', 'Validation')
hold off

figure()
plot(xQuadSVM128ADASYNtrain,yQuadSVM128ADASYNtrain,'LineWidth',2)
hold on
plot(xQuadSVM128ADASYNtest,yQuadSVM128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, Quadratic SVM')
legend('Training', 'Validation')
hold off

figure()
plot(xCubicSVM128ADASYNtrain,yCubicSVM128ADASYNtrain,'LineWidth',2)
hold on
plot(xCubicSVM128ADASYNtest,yCubicSVM128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, Cubic SVM')
legend('Training', 'Validation')
hold off

figure()
plot(xRBFSVM128ADASYNtrain,yRBFSVM128ADASYNtrain,'LineWidth',2)
hold on
plot(xRBFSVM128ADASYNtest,yRBFSVM128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RBF SVM')
legend('Training', 'Validation')
hold off

figure()
plot(x3KNN128ADASYNtrain,y3KNN128ADASYNtrain,'LineWidth',2)
hold on
plot(x3KNN128ADASYNtest,y3KNN128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 3')
legend('Training', 'Validation')
hold off

figure()
plot(x5KNN128ADASYNtrain,y5KNN128ADASYNtrain,'LineWidth',2)
hold on
plot(x5KNN128ADASYNtest,y5KNN128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 5')
legend('Training', 'Validation')
hold off

figure()
plot(x7KNN128ADASYNtrain,y7KNN128ADASYNtrain,'LineWidth',2)
hold on
plot(x7KNN128ADASYNtest,y7KNN128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 7')
legend('Training', 'Validation')
hold off

figure()
plot(x9KNN128ADASYNtrain,y9KNN128ADASYNtrain,'LineWidth',2)
hold on
plot(x9KNN128ADASYNtest,y9KNN128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 9')
legend('Training', 'Validation')
hold off

figure()
plot(x5Tree128ADASYNtrain,y5Tree128ADASYNtrain,'LineWidth',2)
hold on
plot(x5Tree128ADASYNtest,y5Tree128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 5 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x10Tree128ADASYNtrain,y10Tree128ADASYNtrain,'LineWidth',2)
hold on
plot(x10Tree128ADASYNtest,y10Tree128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 10 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x20Tree128ADASYNtrain,y20Tree128ADASYNtrain,'LineWidth',2)
hold on
plot(x20Tree128ADASYNtest,y20Tree128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 20 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x30Tree128ADASYNtrain,y30Tree128ADASYNtrain,'LineWidth',2)
hold on
plot(x30Tree128ADASYNtest,y30Tree128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 30 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x40Tree128ADASYNtrain,y40Tree128ADASYNtrain,'LineWidth',2)
hold on
plot(x40Tree128ADASYNtest,y40Tree128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 40 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x50Tree128ADASYNtrain,y50Tree128ADASYNtrain,'LineWidth',2)
hold on
plot(x50Tree128ADASYNtest,y50Tree128ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 50 Trees')
legend('Training', 'Validation')
hold off


% ROC curve plots, validation only, all models.
figure()
plot(xLinSVM128ADASYNtest,yLinSVM128ADASYNtest,'r','LineWidth',2)
hold on
plot(xQuadSVM128ADASYNtest,yQuadSVM128ADASYNtest,'g','LineWidth',2)
plot(xCubicSVM128ADASYNtest,yCubicSVM128ADASYNtest,'b','LineWidth',2)
plot(xRBFSVM128ADASYNtest,yRBFSVM128ADASYNtest,'c','LineWidth',2)
plot(x3KNN128ADASYNtest,y3KNN128ADASYNtest,'m','LineWidth',2)
plot(x5KNN128ADASYNtest,y5KNN128ADASYNtest,'y','LineWidth',2)
plot(x7KNN128ADASYNtest,y7KNN128ADASYNtest,'k','LineWidth',2)
plot(x9KNN128ADASYNtest,y9KNN128ADASYNtest,'r--','LineWidth',2)
plot(x5Tree128ADASYNtest,y5Tree128ADASYNtest,'g--','LineWidth',2)
plot(x10Tree128ADASYNtest,y10Tree128ADASYNtest,'b--','LineWidth',2)
plot(x20Tree128ADASYNtest,y20Tree128ADASYNtest,'c--','LineWidth',2)
plot(x30Tree128ADASYNtest,y30Tree128ADASYNtest,'m--','LineWidth',2)
plot(x40Tree128ADASYNtest,y40Tree128ADASYNtest,'y--','LineWidth',2)
plot(x50Tree128ADASYNtest,y50Tree128ADASYNtest,'k--','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, all models, validation only')
legend('Linear SVM', 'Quadratic SVM','Cubic SVM','RBF SVM','kNN, k=3',...
    'kNN, k=5','kNN, k=7','kNN, k=9','RF, 5 Trees', 'RF, 10 Trees',...
    'RF, 20 Trees','RF, 30 Trees','RF, 40 Trees', 'RF, 50 Trees','Location','SouthEast')

AUCtrain = [aucLinSVM128ADASYNtrain;aucQuadSVM128ADASYNtrain;aucCubicSVM128ADASYNtrain;aucRBFSVM128ADASYNtrain;...
    auc3KNN128ADASYNtrain;auc5KNN128ADASYNtrain;auc7KNN128ADASYNtrain;auc9KNN128ADASYNtrain;auc5Tree128ADASYNtrain;...
    auc10Tree128ADASYNtrain;auc20Tree128ADASYNtrain;auc30Tree128ADASYNtrain;auc40Tree128ADASYNtrain;...
    auc50Tree128ADASYNtrain];

AUCtest = [aucLinSVM128ADASYNtest;aucQuadSVM128ADASYNtest;aucCubicSVM128ADASYNtest;aucRBFSVM128ADASYNtest;...
    auc3KNN128ADASYNtest;auc5KNN128ADASYNtest;auc7KNN128ADASYNtest;auc9KNN128ADASYNtest;auc5Tree128ADASYNtest;...
    auc10Tree128ADASYNtest;auc20Tree128ADASYNtest;auc30Tree128ADASYNtest;auc40Tree128ADASYNtest;...
    auc50Tree128ADASYNtest];

meanTime = [m1;m2;m3;m4;m5;m6;m7;m8;m9;m10;m11;m12;m13;m14];
totalTime = [s1;s2;s3;s4;s5;s6;s7;s8;s9;s10;s11;s12;s13;s14];

T = table(AUCtrain,AUCtest,meanTime,totalTime);

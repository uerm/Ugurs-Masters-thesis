function T = trainClassifier20ADASYN(trainingData)

indices = crossvalind('Kfold',trainingData(:,end),10);

% Linear SVM
targetsLinSVM20ADASYNtrain_all = [];
predsLinSVM20ADASYNtrain_all = [];
scoresLinSVM20ADASYNtrain_all = [];

targetsLinSVM20ADASYNtest_all = [];
predsLinSVM20ADASYNtest_all = [];
scoresLinSVM20ADASYNtest_all = [];

% Quadratic SVM
targetsQuadSVM20ADASYNtrain_all = [];
predsQuadSVM20ADASYNtrain_all = [];
scoresQuadSVM20ADASYNtrain_all = [];

targetsQuadSVM20ADASYNtest_all = [];
predsQuadSVM20ADASYNtest_all = [];
scoresQuadSVM20ADASYNtest_all = [];

% Cubic SVM
targetsCubicSVM20ADASYNtrain_all = [];
predsCubicSVM20ADASYNtrain_all = [];
scoresCubicSVM20ADASYNtrain_all = [];

targetsCubicSVM20ADASYNtest_all = [];
predsCubicSVM20ADASYNtest_all = [];
scoresCubicSVM20ADASYNtest_all = [];

% RBF SVM
targetsRBFSVM20ADASYNtrain_all = [];
predsRBFSVM20ADASYNtrain_all = [];
scoresRBFSVM20ADASYNtrain_all = [];

targetsRBFSVM20ADASYNtest_all = [];
predsRBFSVM20ADASYNtest_all = [];
scoresRBFSVM20ADASYNtest_all = [];

% 3kNN
targets3KNN20ADASYNtrain_all = [];
preds3KNN20ADASYNtrain_all = [];
scores3KNN20ADASYNtrain_all = [];

targets3KNN20ADASYNtest_all = [];
preds3KNN20ADASYNtest_all = [];
scores3KNN20ADASYNtest_all = [];

% 5kNN
targets5KNN20ADASYNtrain_all = [];
preds5KNN20ADASYNtrain_all = [];
scores5KNN20ADASYNtrain_all = [];

targets5KNN20ADASYNtest_all = [];
preds5KNN20ADASYNtest_all = [];
scores5KNN20ADASYNtest_all = [];

% 7 kNN
targets7KNN20ADASYNtrain_all = [];
preds7KNN20ADASYNtrain_all = [];
scores7KNN20ADASYNtrain_all = [];

targets7KNN20ADASYNtest_all = [];
preds7KNN20ADASYNtest_all = [];
scores7KNN20ADASYNtest_all = [];

% 9 kNN
targets9KNN20ADASYNtrain_all = [];
preds9KNN20ADASYNtrain_all = [];
scores9KNN20ADASYNtrain_all = [];

targets9KNN20ADASYNtest_all = [];
preds9KNN20ADASYNtest_all = [];
scores9KNN20ADASYNtest_all = [];

% RF, 5 Trees
targets5Tree20ADASYNtrain_all = [];
preds5Tree20ADASYNtrain_all = [];
scores5Tree20ADASYNtrain_all = [];

targets5Tree20ADASYNtest_all = [];
preds5Tree20ADASYNtest_all = [];
scores5Tree20ADASYNtest_all = [];

% RF, 10 Trees
targets10Tree20ADASYNtrain_all = [];
preds10Tree20ADASYNtrain_all = [];
scores10Tree20ADASYNtrain_all = [];

targets10Tree20ADASYNtest_all = [];
preds10Tree20ADASYNtest_all = [];
scores10Tree20ADASYNtest_all = [];

% RF, 20 Trees
targets20Tree20ADASYNtrain_all = [];
preds20Tree20ADASYNtrain_all = [];
scores20Tree20ADASYNtrain_all = [];

targets20Tree20ADASYNtest_all = [];
preds20Tree20ADASYNtest_all = [];
scores20Tree20ADASYNtest_all = [];

% RF, 30 Trees
targets30Tree20ADASYNtrain_all = [];
preds30Tree20ADASYNtrain_all = [];
scores30Tree20ADASYNtrain_all = [];

targets30Tree20ADASYNtest_all = [];
preds30Tree20ADASYNtest_all = [];
scores30Tree20ADASYNtest_all = [];

% RF, 40 Trees
targets40Tree20ADASYNtrain_all = [];
preds40Tree20ADASYNtrain_all = [];
scores40Tree20ADASYNtrain_all = [];

targets40Tree20ADASYNtest_all = [];
preds40Tree20ADASYNtest_all = [];
scores40Tree20ADASYNtest_all = [];

% RF, 50 Trees
targets50Tree20ADASYNtrain_all = [];
preds50Tree20ADASYNtrain_all = [];
scores50Tree20ADASYNtrain_all = [];

targets50Tree20ADASYNtest_all = [];
preds50Tree20ADASYNtest_all = [];
scores50Tree20ADASYNtest_all = [];

for i = 1:10
    test = (indices == i); 
    train = ~test;
    
    % Linear SVM
    tic
    classificationLinearSVM20ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'linear', ...
    'PolynomialOrder', [], ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);

    % Training
    [predsLinSVM20ADASYNtrain,~] = predict(classificationLinearSVM20ADASYN,trainingData(train,1:end-1));
    t1{1,i} = toc;
    targetsLinSVM20ADASYNtrain = trainingData(train,end);
    targetsLinSVM20ADASYNtrain_all = [targetsLinSVM20ADASYNtrain_all; squeeze(targetsLinSVM20ADASYNtrain)];
    predsLinSVM20ADASYNtrain_all = [predsLinSVM20ADASYNtrain_all; squeeze(predsLinSVM20ADASYNtrain)];
    
    [~,scoresLinSVM20ADASYN] = resubPredict(fitPosterior(classificationLinearSVM20ADASYN));
    scoresLinSVM20ADASYNtrain_all = [scoresLinSVM20ADASYNtrain_all;scoresLinSVM20ADASYN(:,2)];
    
    % Validation
    [predsLinSVM20ADASYNtest,scoresLinSVM20ADASYNtest] = predict(classificationLinearSVM20ADASYN,trainingData(test,1:end-1));
    targetsLinSVM20ADASYNtest = trainingData(test,end);
    targetsLinSVM20ADASYNtest_all = [targetsLinSVM20ADASYNtest_all; squeeze(targetsLinSVM20ADASYNtest)];
    predsLinSVM20ADASYNtest_all = [predsLinSVM20ADASYNtest_all; squeeze(predsLinSVM20ADASYNtest)];
    
    scoresLinSVM20ADASYNtest_all = [scoresLinSVM20ADASYNtest_all; scoresLinSVM20ADASYNtest(:,2)];
    
    
    % Quadratic SVM
    tic
    classificationQuadSVM20ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'polynomial', ...
    'PolynomialOrder', 2, ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);

    % Training
    [predsQuadSVM20ADASYNtrain,~] = predict(classificationQuadSVM20ADASYN,trainingData(train,1:end-1));
    t2{1,i} = toc;
    targetsQuadSVM20ADASYNtrain = trainingData(train,end);
    targetsQuadSVM20ADASYNtrain_all = [targetsQuadSVM20ADASYNtrain_all; squeeze(targetsQuadSVM20ADASYNtrain)];
    predsQuadSVM20ADASYNtrain_all = [predsQuadSVM20ADASYNtrain_all; squeeze(predsQuadSVM20ADASYNtrain)];
    
    [~,scoresQuadSVM20ADASYN] = resubPredict(fitPosterior(classificationQuadSVM20ADASYN));
    scoresQuadSVM20ADASYNtrain_all = [scoresQuadSVM20ADASYNtrain_all; scoresQuadSVM20ADASYN(:,2)];
    
    % Validation
    [predsQuadSVM20ADASYNtest,scoresQuadSVM20ADASYNtest] = predict(classificationQuadSVM20ADASYN,trainingData(test,1:end-1));
    targetsQuadSVM20ADASYNtest = trainingData(test,end);
    targetsQuadSVM20ADASYNtest_all = [targetsQuadSVM20ADASYNtest_all; squeeze(targetsQuadSVM20ADASYNtest)];
    predsQuadSVM20ADASYNtest_all = [predsQuadSVM20ADASYNtest_all; squeeze(predsQuadSVM20ADASYNtest)];
    
    scoresQuadSVM20ADASYNtest_all = [scoresQuadSVM20ADASYNtest_all; scoresQuadSVM20ADASYNtest(:,2)];
    
    
    % Cubic SVM
    tic
    classificationCubicSVM20ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'polynomial', ...
    'PolynomialOrder', 3, ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);

    % Training
    [predsCubicSVM20ADASYNtrain,~] = predict(classificationCubicSVM20ADASYN,trainingData(train,1:end-1));
    t3{1,i} = toc;
    targetsCubicSVM20ADASYNtrain = trainingData(train,end);
    targetsCubicSVM20ADASYNtrain_all = [targetsCubicSVM20ADASYNtrain_all; squeeze(targetsCubicSVM20ADASYNtrain)];
    predsCubicSVM20ADASYNtrain_all = [predsCubicSVM20ADASYNtrain_all; squeeze(predsCubicSVM20ADASYNtrain)];
    
    [~,scoresCubicSVM20ADASYN] = resubPredict(fitPosterior(classificationCubicSVM20ADASYN));
    scoresCubicSVM20ADASYNtrain_all = [scoresCubicSVM20ADASYNtrain_all; scoresCubicSVM20ADASYN(:,2)];    
    
    % Validation
    [predsCubicSVM20ADASYNtest,scoresCubicSVM20ADASYNtest] = predict(classificationCubicSVM20ADASYN,trainingData(test,1:end-1));
    targetsCubicSVM20ADASYNtest = trainingData(test,end);
    targetsCubicSVM20ADASYNtest_all = [targetsCubicSVM20ADASYNtest_all; squeeze(targetsCubicSVM20ADASYNtest)];
    predsCubicSVM20ADASYNtest_all = [predsCubicSVM20ADASYNtest_all; squeeze(predsCubicSVM20ADASYNtest)];
    
    scoresCubicSVM20ADASYNtest_all = [scoresCubicSVM20ADASYNtest_all; scoresCubicSVM20ADASYNtest(:,2)];
    
    
    % RBF SVM
    tic
    classificationRBFSVM20ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'RBF', ...
    'PolynomialOrder', [], ...
    'KernelScale', 'auto', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);
    
    % Training
    [predsRBFSVM20ADASYNtrain,~] = predict(classificationRBFSVM20ADASYN,trainingData(train,1:end-1));
    t4{1,i} = toc;
    targetsRBFSVM20ADASYNtrain = trainingData(train,end);
    targetsRBFSVM20ADASYNtrain_all = [targetsRBFSVM20ADASYNtrain_all; squeeze(targetsRBFSVM20ADASYNtrain)];
    predsRBFSVM20ADASYNtrain_all = [predsRBFSVM20ADASYNtrain_all; squeeze(predsRBFSVM20ADASYNtrain)];
    
    [~,scoresRBFSVM20ADASYN] = resubPredict(fitPosterior(classificationRBFSVM20ADASYN));
    scoresRBFSVM20ADASYNtrain_all = [scoresRBFSVM20ADASYNtrain_all; scoresRBFSVM20ADASYN(:,2)];    
    
    % Validation
    [predsRBFSVM20ADASYNtest,scoresRBFSVM20ADASYNtest] = predict(classificationRBFSVM20ADASYN,trainingData(test,1:end-1));
    targetsRBFSVM20ADASYNtest = trainingData(test,end);
    targetsRBFSVM20ADASYNtest_all = [targetsRBFSVM20ADASYNtest_all; squeeze(targetsRBFSVM20ADASYNtest)];
    predsRBFSVM20ADASYNtest_all = [predsRBFSVM20ADASYNtest_all; squeeze(predsRBFSVM20ADASYNtest)];
    
    scoresRBFSVM20ADASYNtest_all = [scoresRBFSVM20ADASYNtest_all; scoresRBFSVM20ADASYNtest(:,2)];
    
    
    % kNN, 3 neighbors
    tic
    classification3KNN20ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 3, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds3KNN20ADASYNtrain,~] = predict(classification3KNN20ADASYN,trainingData(train,1:end-1));
    t5{1,i} = toc;
    targets3KNN20ADASYNtrain = trainingData(train,end);
    targets3KNN20ADASYNtrain_all = [targets3KNN20ADASYNtrain_all; squeeze(targets3KNN20ADASYNtrain)];
    preds3KNN20ADASYNtrain_all = [preds3KNN20ADASYNtrain_all; squeeze(preds3KNN20ADASYNtrain)];
    
    [~,scores3KNN20ADASYN] = resubPredict(classification3KNN20ADASYN);
    scores3KNN20ADASYNtrain_all = [scores3KNN20ADASYNtrain_all; scores3KNN20ADASYN(:,2)];    
    
    % Validation
    [preds3KNN20ADASYNtest,scores3KNN20ADASYNtest] = predict(classification3KNN20ADASYN,trainingData(test,1:end-1));
    targets3KNN20ADASYNtest = trainingData(test,end);
    targets3KNN20ADASYNtest_all = [targets3KNN20ADASYNtest_all; squeeze(targets3KNN20ADASYNtest)];
    preds3KNN20ADASYNtest_all = [preds3KNN20ADASYNtest_all; squeeze(preds3KNN20ADASYNtest)];
    
    scores3KNN20ADASYNtest_all = [scores3KNN20ADASYNtest_all; scores3KNN20ADASYNtest(:,2)];
    
    
    % kNN, 5 neighbors
    tic
    classification5KNN20ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 5, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds5KNN20ADASYNtrain,~] = predict(classification5KNN20ADASYN,trainingData(train,1:end-1));
    t6{1,i} = toc;
    targets5KNN20ADASYNtrain = trainingData(train,end);
    targets5KNN20ADASYNtrain_all = [targets5KNN20ADASYNtrain_all; squeeze(targets5KNN20ADASYNtrain)];
    preds5KNN20ADASYNtrain_all = [preds5KNN20ADASYNtrain_all; squeeze(preds5KNN20ADASYNtrain)];
    
    [~,scores5KNN20ADASYN] = resubPredict(classification5KNN20ADASYN);
    scores5KNN20ADASYNtrain_all = [scores5KNN20ADASYNtrain_all; scores5KNN20ADASYN(:,2)];    
    
    % Validation
    [preds5KNN20ADASYNtest,scores5KNN20ADASYNtest] = predict(classification5KNN20ADASYN,trainingData(test,1:end-1));
    targets5KNN20ADASYNtest = trainingData(test,end);
    targets5KNN20ADASYNtest_all = [targets5KNN20ADASYNtest_all; squeeze(targets5KNN20ADASYNtest)];
    preds5KNN20ADASYNtest_all = [preds5KNN20ADASYNtest_all; squeeze(preds5KNN20ADASYNtest)];
    
    scores5KNN20ADASYNtest_all = [scores5KNN20ADASYNtest_all; scores5KNN20ADASYNtest(:,2)];
    
    
    % kNN, 7 neighbors
    tic
    classification7KNN20ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 7, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds7KNN20ADASYNtrain,~] = predict(classification7KNN20ADASYN,trainingData(train,1:end-1));
    t7{1,i} = toc;
    targets7KNN20ADASYNtrain = trainingData(train,end);
    targets7KNN20ADASYNtrain_all = [targets7KNN20ADASYNtrain_all; squeeze(targets7KNN20ADASYNtrain)];
    preds7KNN20ADASYNtrain_all = [preds7KNN20ADASYNtrain_all; squeeze(preds7KNN20ADASYNtrain)];
    
    [~,scores7KNN20ADASYN] = resubPredict(classification7KNN20ADASYN);
    scores7KNN20ADASYNtrain_all = [scores7KNN20ADASYNtrain_all; scores7KNN20ADASYN(:,2)];    
    
    % Validation
    [preds7KNN20ADASYNtest,scores7KNN20ADASYNtest] = predict(classification7KNN20ADASYN,trainingData(test,1:end-1));
    targets7KNN20ADASYNtest = trainingData(test,end);
    targets7KNN20ADASYNtest_all = [targets7KNN20ADASYNtest_all; squeeze(targets7KNN20ADASYNtest)];
    preds7KNN20ADASYNtest_all = [preds7KNN20ADASYNtest_all; squeeze(preds7KNN20ADASYNtest)];
    
    scores7KNN20ADASYNtest_all = [scores7KNN20ADASYNtest_all; scores7KNN20ADASYNtest(:,2)];
    
    
    % kNN, 9 neighbors
    tic
    classification9KNN20ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 9, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds9KNN20ADASYNtrain,~] = predict(classification9KNN20ADASYN,trainingData(train,1:end-1));
    t8{1,i} = toc;
    targets9KNN20ADASYNtrain = trainingData(train,end);
    targets9KNN20ADASYNtrain_all = [targets9KNN20ADASYNtrain_all; squeeze(targets9KNN20ADASYNtrain)];
    preds9KNN20ADASYNtrain_all = [preds9KNN20ADASYNtrain_all; squeeze(preds9KNN20ADASYNtrain)];
    
    [~,scores9KNN20ADASYN] = resubPredict(classification9KNN20ADASYN);
    scores9KNN20ADASYNtrain_all = [scores9KNN20ADASYNtrain_all; scores9KNN20ADASYN(:,2)];    
    
    % Validation
    [preds9KNN20ADASYNtest,scores9KNN20ADASYNtest] = predict(classification9KNN20ADASYN,trainingData(test,1:end-1));
    targets9KNN20ADASYNtest = trainingData(test,end);
    targets9KNN20ADASYNtest_all = [targets9KNN20ADASYNtest_all; squeeze(targets9KNN20ADASYNtest)];
    preds9KNN20ADASYNtest_all = [preds9KNN20ADASYNtest_all; squeeze(preds9KNN20ADASYNtest)];
    
    scores9KNN20ADASYNtest_all = [scores9KNN20ADASYNtest_all; scores9KNN20ADASYNtest(:,2)];
    
    
    % RF, 5 Trees
    tic
    classification5Tree20ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 5, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds5Tree20ADASYNtrain,~] = predict(classification5Tree20ADASYN,trainingData(train,1:end-1));
    t9{1,i} = toc;
    targets5Tree20ADASYNtrain = trainingData(train,end);
    targets5Tree20ADASYNtrain_all = [targets5Tree20ADASYNtrain_all; squeeze(targets5Tree20ADASYNtrain)];
    preds5Tree20ADASYNtrain_all = [preds5Tree20ADASYNtrain_all; squeeze(preds5Tree20ADASYNtrain)];
    
    [~,scores5Tree20ADASYN] = resubPredict(classification5Tree20ADASYN);
    scores5Tree20ADASYNtrain_all = [scores5Tree20ADASYNtrain_all; scores5Tree20ADASYN(:,2)];    
    
    % Validation
    [preds5Tree20ADASYNtest,scores5Tree20ADASYNtest] = predict(classification5Tree20ADASYN,trainingData(test,1:end-1));
    targets5Tree20ADASYNtest = trainingData(test,end);
    targets5Tree20ADASYNtest_all = [targets5Tree20ADASYNtest_all; squeeze(targets5Tree20ADASYNtest)];
    preds5Tree20ADASYNtest_all = [preds5Tree20ADASYNtest_all; squeeze(preds5Tree20ADASYNtest)];
    
    scores5Tree20ADASYNtest_all = [scores5Tree20ADASYNtest_all; scores5Tree20ADASYNtest(:,2)];
    
    
    
    % RF, 10 Trees
    tic
    classification10Tree20ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 10, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds10Tree20ADASYNtrain,~] = predict(classification10Tree20ADASYN,trainingData(train,1:end-1));
    t10{1,i} = toc;
    targets10Tree20ADASYNtrain = trainingData(train,end);
    targets10Tree20ADASYNtrain_all = [targets10Tree20ADASYNtrain_all; squeeze(targets10Tree20ADASYNtrain)];
    preds10Tree20ADASYNtrain_all = [preds10Tree20ADASYNtrain_all; squeeze(preds10Tree20ADASYNtrain)];
    
    [~,scores10Tree20ADASYN] = resubPredict(classification10Tree20ADASYN);
    scores10Tree20ADASYNtrain_all = [scores10Tree20ADASYNtrain_all; scores10Tree20ADASYN(:,2)];      
    
    % Validation
    [preds10Tree20ADASYNtest,scores10Tree20ADASYNtest] = predict(classification10Tree20ADASYN,trainingData(test,1:end-1));
    targets10Tree20ADASYNtest = trainingData(test,end);
    targets10Tree20ADASYNtest_all = [targets10Tree20ADASYNtest_all; squeeze(targets10Tree20ADASYNtest)];
    preds10Tree20ADASYNtest_all = [preds10Tree20ADASYNtest_all; squeeze(preds10Tree20ADASYNtest)];
    
    scores10Tree20ADASYNtest_all = [scores10Tree20ADASYNtest_all; scores10Tree20ADASYNtest(:,2)];
    
    
    
    % RF, 20 Trees
    tic
    classification20Tree20ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 20, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds20Tree20ADASYNtrain,~] = predict(classification20Tree20ADASYN,trainingData(train,1:end-1));
    t11{1,i} = toc;
    targets20Tree20ADASYNtrain = trainingData(train,end);
    targets20Tree20ADASYNtrain_all = [targets20Tree20ADASYNtrain_all; squeeze(targets20Tree20ADASYNtrain)];
    preds20Tree20ADASYNtrain_all = [preds20Tree20ADASYNtrain_all; squeeze(preds20Tree20ADASYNtrain)];
    
    [~,scores20Tree20ADASYN] = resubPredict(classification20Tree20ADASYN);
    scores20Tree20ADASYNtrain_all = [scores20Tree20ADASYNtrain_all; scores20Tree20ADASYN(:,2)];    
    
    % Validation
    [preds20Tree20ADASYNtest,scores20Tree20ADASYNtest] = predict(classification20Tree20ADASYN,trainingData(test,1:end-1));
    targets20Tree20ADASYNtest = trainingData(test,end);
    targets20Tree20ADASYNtest_all = [targets20Tree20ADASYNtest_all; squeeze(targets20Tree20ADASYNtest)];
    preds20Tree20ADASYNtest_all = [preds20Tree20ADASYNtest_all; squeeze(preds20Tree20ADASYNtest)];
    
    scores20Tree20ADASYNtest_all = [scores20Tree20ADASYNtest_all; scores20Tree20ADASYNtest(:,2)]; 
    
    
    % RF, 30 Trees
    tic
    classification30Tree20ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 30, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds30Tree20ADASYNtrain,~] = predict(classification30Tree20ADASYN,trainingData(train,1:end-1));
    t12{1,i} = toc;
    targets30Tree20ADASYNtrain = trainingData(train,end);
    targets30Tree20ADASYNtrain_all = [targets30Tree20ADASYNtrain_all; squeeze(targets30Tree20ADASYNtrain)];
    preds30Tree20ADASYNtrain_all = [preds30Tree20ADASYNtrain_all; squeeze(preds30Tree20ADASYNtrain)];
    
    [~,scores30Tree20ADASYN] = resubPredict(classification30Tree20ADASYN);
    scores30Tree20ADASYNtrain_all = [scores30Tree20ADASYNtrain_all; scores30Tree20ADASYN(:,2)];    
    
    % Validation
    [preds30Tree20ADASYNtest,scores30Tree20ADASYNtest] = predict(classification30Tree20ADASYN,trainingData(test,1:end-1));
    targets30Tree20ADASYNtest = trainingData(test,end);
    targets30Tree20ADASYNtest_all = [targets30Tree20ADASYNtest_all; squeeze(targets30Tree20ADASYNtest)];
    preds30Tree20ADASYNtest_all = [preds30Tree20ADASYNtest_all; squeeze(preds30Tree20ADASYNtest)];
    
    scores30Tree20ADASYNtest_all = [scores30Tree20ADASYNtest_all; scores30Tree20ADASYNtest(:,2)];
    
    
    % RF, 40 Trees
    tic
    classification40Tree20ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 40, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds40Tree20ADASYNtrain,~] = predict(classification40Tree20ADASYN,trainingData(train,1:end-1));
    t13{1,i} = toc;
    targets40Tree20ADASYNtrain = trainingData(train,end);
    targets40Tree20ADASYNtrain_all = [targets40Tree20ADASYNtrain_all; squeeze(targets40Tree20ADASYNtrain)];
    preds40Tree20ADASYNtrain_all = [preds40Tree20ADASYNtrain_all; squeeze(preds40Tree20ADASYNtrain)];
    
    [~,scores40Tree20ADASYN] = resubPredict(classification40Tree20ADASYN);
    scores40Tree20ADASYNtrain_all = [scores40Tree20ADASYNtrain_all; scores40Tree20ADASYN(:,2)];    
    
    % Validation
    [preds40Tree20ADASYNtest,scores40Tree20ADASYNtest] = predict(classification40Tree20ADASYN,trainingData(test,1:end-1));
    targets40Tree20ADASYNtest = trainingData(test,end);
    targets40Tree20ADASYNtest_all = [targets40Tree20ADASYNtest_all; squeeze(targets40Tree20ADASYNtest)];
    preds40Tree20ADASYNtest_all = [preds40Tree20ADASYNtest_all; squeeze(preds40Tree20ADASYNtest)];
    
    scores40Tree20ADASYNtest_all = [scores40Tree20ADASYNtest_all; scores40Tree20ADASYNtest(:,2)];
    
    
    % RF, 50 Trees
    tic
    classification50Tree20ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 50, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds50Tree20ADASYNtrain,~] = predict(classification50Tree20ADASYN,trainingData(train,1:end-1));
    t14{1,i} = toc;
    targets50Tree20ADASYNtrain = trainingData(train,end);
    targets50Tree20ADASYNtrain_all = [targets50Tree20ADASYNtrain_all; squeeze(targets50Tree20ADASYNtrain)];
    preds50Tree20ADASYNtrain_all = [preds50Tree20ADASYNtrain_all; squeeze(preds50Tree20ADASYNtrain)];
    
    [~,scores50Tree20ADASYN] = resubPredict(classification50Tree20ADASYN);
    scores50Tree20ADASYNtrain_all = [scores50Tree20ADASYNtrain_all; scores50Tree20ADASYN(:,2)];    
    
    % Validation
    [preds50Tree20ADASYNtest,scores50Tree20ADASYNtest] = predict(classification50Tree20ADASYN,trainingData(test,1:end-1));
    targets50Tree20ADASYNtest = trainingData(test,end);
    targets50Tree20ADASYNtest_all = [targets50Tree20ADASYNtest_all; squeeze(targets50Tree20ADASYNtest)];
    preds50Tree20ADASYNtest_all = [preds50Tree20ADASYNtest_all; squeeze(preds50Tree20ADASYNtest)];
    
    scores50Tree20ADASYNtest_all = [scores50Tree20ADASYNtest_all; scores50Tree20ADASYNtest(:,2)];
end

save('classificationLinearSVM20ADASYN.mat','classificationLinearSVM20ADASYN','-v7.3'); % majority voting
%save('classificationLinearSVM20ADASYN_30.mat','classificationLinearSVM20ADASYN','-v7.3'); % Threshold 30%
%save('classificationLinearSVM20ADASYN_20.mat','classificationLinearSVM20ADASYN','-v7.3'); % Threshold 20%
%save('classificationLinearSVM20ADASYN_10.mat','classificationLinearSVM20ADASYN','-v7.3'); % Threshold 10%

save('classificationQuadSVM20ADASYN.mat','classificationQuadSVM20ADASYN','-v7.3'); % majority voting
%save('classificationQuadSVM20ADASYN_30.mat','classificationQuadSVM20ADASYN','-v7.3'); % Threshold 30%
%save('classificationQuadSVM20ADASYN_20.mat','classificationQuadSVM20ADASYN','-v7.3'); % Threshold 20%
%save('classificationQuadSVM20ADASYN_10.mat','classificationQuadSVM20ADASYN','-v7.3'); % Threshold 10%

save('classificationCubicSVM20ADASYN.mat','classificationCubicSVM20ADASYN','-v7.3'); % majority voting
%save('classificationCubicSVM20ADASYN_30.mat','classificationCubicSVM20ADASYN','-v7.3'); % Threshold 30%
%save('classificationCubicSVM20ADASYN_20.mat','classificationCubicSVM20ADASYN','-v7.3'); % Threshold 20%
%save('classificationCubicSVM20ADASYN_10.mat','classificationCubicSVM20ADASYN','-v7.3'); % Threshold 10%

save('classificationRBFSVM20ADASYN.mat','classificationRBFSVM20ADASYN','-v7.3'); % majority voting
%save('classificationRBFSVM20ADASYN_30.mat','classificationRBFSVM20ADASYN','-v7.3'); % Threshold 30%
%save('classificationRBFSVM20ADASYN_20.mat','classificationRBFSVM20ADASYN','-v7.3'); % Threshold 20%
%save('classificationRBFSVM20ADASYN_10.mat','classificationRBFSVM20ADASYN','-v7.3'); % Threshold 10%

save('classification3KNN20ADASYN.mat','classification3KNN20ADASYN','-v7.3'); % majority voting
%save('classification3KNN20ADASYN_30.mat','classification3KNN20ADASYN','-v7.3'); % Threshold 30%
%save('classification3KNN20ADASYN_20.mat','classification3KNN20ADASYN','-v7.3'); % Threshold 20%
%save('classification3KNN20ADASYN_10.mat','classification3KNN20ADASYN','-v7.3'); % Threshold 10%

save('classification5KNN20ADASYN.mat','classification5KNN20ADASYN','-v7.3'); % majority voting
%save('classification5KNN20ADASYN_30.mat','classification5KNN20ADASYN','-v7.3'); % Threshold 30%
%save('classification5KNN20ADASYN_20.mat','classification5KNN20ADASYN','-v7.3'); % Threshold 20%
%save('classification5KNN20ADASYN_10.mat','classification5KNN20ADASYN','-v7.3'); % Threshold 10%

save('classification7KNN20ADASYN.mat','classification7KNN20ADASYN','-v7.3'); % majority voting
%save('classification7KNN20ADASYN_30.mat','classification7KNN20ADASYN','-v7.3'); % Threshold 30%
%save('classification7KNN20ADASYN_20.mat','classification7KNN20ADASYN','-v7.3'); % Threshold 20%
%save('classification7KNN20ADASYN_10.mat','classification7KNN20ADASYN','-v7.3'); % Threshold 10%

save('classification9KNN20ADASYN.mat','classification9KNN20ADASYN','-v7.3'); % majority voting
%save('classification9KNN20ADASYN_30.mat','classification9KNN20ADASYN','-v7.3'); % Threshold 30%
%save('classification9KNN20ADASYN_20.mat','classification9KNN20ADASYN','-v7.3'); % Threshold 20%
%save('classification9KNN20ADASYN_10.mat','classification9KNN20ADASYN','-v7.3'); % Threshold 10%

save('classification5Tree20ADASYN.mat','classification5Tree20ADASYN','-v7.3'); % majority voting
%save('classification5Tree20ADASYN_30.mat','classification5Tree20ADASYN','-v7.3'); % Threshold 30%
%save('classification5Tree20ADASYN_20.mat','classification5Tree20ADASYN','-v7.3'); % Threshold 20%
%save('classification5Tree20ADASYN_10.mat','classification5Tree20ADASYN','-v7.3'); % Threshold 10%

save('classification10Tree20ADASYN.mat','classification10Tree20ADASYN','-v7.3'); % majority voting
%save('classification10Tree20ADASYN_30.mat','classification10Tree20ADASYN','-v7.3'); % Threshold 30%
%save('classification10Tree20ADASYN_20.mat','classification10Tree20ADASYN','-v7.3'); % Threshold 20%
%save('classification10Tree20ADASYN_10.mat','classification10Tree20ADASYN','-v7.3'); % Threshold 10%

save('classification20Tree20ADASYN.mat','classification20Tree20ADASYN','-v7.3'); % majority voting
%save('classification20Tree20ADASYN_30.mat','classification20Tree20ADASYN','-v7.3'); % Threshold 30%
%save('classification20Tree20ADASYN_20.mat','classification20Tree20ADASYN','-v7.3'); % Threshold 20%
%save('classification20Tree20ADASYN_10.mat','classification20Tree20ADASYN','-v7.3'); % Threshold 10%

save('classification30Tree20ADASYN.mat','classification30Tree20ADASYN','-v7.3'); % majority voting
%save('classification30Tree20ADASYN_30.mat','classification30Tree20ADASYN','-v7.3'); % Threshold 30%
%save('classification30Tree20ADASYN_20.mat','classification30Tree20ADASYN','-v7.3'); % Threshold 20%
%save('classification30Tree20ADASYN_10.mat','classification30Tree20ADASYN','-v7.3'); % Threshold 10%

save('classification40Tree20ADASYN.mat','classification40Tree20ADASYN','-v7.3'); % majority voting
%save('classification40Tree20ADASYN_30.mat','classification40Tree20ADASYN','-v7.3'); % Threshold 30%
%save('classification40Tree20ADASYN_20.mat','classification40Tree20ADASYN','-v7.3'); % Threshold 20%
%save('classification40Tree20ADASYN_10.mat','classification40Tree20ADASYN','-v7.3'); % Threshold 10%

save('classification50Tree20ADASYN.mat','classification50Tree20ADASYN','-v7.3'); % majority voting
%save('classification50Tree20ADASYN_30.mat','classification50Tree20ADASYN','-v7.3'); % Threshold 30%
%save('classification50Tree20ADASYN_20.mat','classification50Tree20ADASYN','-v7.3'); % Threshold 20%
%save('classification50Tree20ADASYN_10.mat','classification50Tree20ADASYN','-v7.3'); % Threshold 10%


m1 = mean([t1{:}]);
m2 = mean([t2{:}]);
m3 = mean([t3{:}]);
m4 = mean([t4{:}]);
m5 = mean([t5{:}]);
m6 = mean([t6{:}]);
m7 = mean([t7{:}]);
m8 = mean([t8{:}]);
m9 = mean([t9{:}]);
m10 = mean([t10{:}]);
m11 = mean([t11{:}]);
m12 = mean([t12{:}]);
m13 = mean([t13{:}]);
m14 = mean([t14{:}]);

s1 = sum([t1{:}]);
s2 = sum([t2{:}]);
s3 = sum([t3{:}]);
s4 = sum([t4{:}]);
s5 = sum([t5{:}]);
s6 = sum([t6{:}]);
s7 = sum([t7{:}]);
s8 = sum([t8{:}]);
s9 = sum([t9{:}]);
s10 = sum([t10{:}]);
s11 = sum([t11{:}]);
s12 = sum([t12{:}]);
s13 = sum([t13{:}]);
s14 = sum([t14{:}]);




% Linear SVM
[xLinSVM20ADASYNtrain,yLinSVM20ADASYNtrain,~,aucLinSVM20ADASYNtrain] = perfcurve(targetsLinSVM20ADASYNtrain_all,scoresLinSVM20ADASYNtrain_all,1);
[xLinSVM20ADASYNtest,yLinSVM20ADASYNtest,~,aucLinSVM20ADASYNtest] = perfcurve(targetsLinSVM20ADASYNtest_all,scoresLinSVM20ADASYNtest_all,1);

% Quadratic SVM
[xQuadSVM20ADASYNtrain,yQuadSVM20ADASYNtrain,~,aucQuadSVM20ADASYNtrain] = perfcurve(targetsQuadSVM20ADASYNtrain_all,scoresQuadSVM20ADASYNtrain_all,1);
[xQuadSVM20ADASYNtest,yQuadSVM20ADASYNtest,~,aucQuadSVM20ADASYNtest] = perfcurve(targetsQuadSVM20ADASYNtest_all,scoresQuadSVM20ADASYNtest_all,1);

% Cubic SVM
[xCubicSVM20ADASYNtrain,yCubicSVM20ADASYNtrain,~,aucCubicSVM20ADASYNtrain] = perfcurve(targetsCubicSVM20ADASYNtrain_all,scoresCubicSVM20ADASYNtrain_all,1);
[xCubicSVM20ADASYNtest,yCubicSVM20ADASYNtest,~,aucCubicSVM20ADASYNtest] = perfcurve(targetsCubicSVM20ADASYNtest_all,scoresCubicSVM20ADASYNtest_all,1);

% RBF SVM
[xRBFSVM20ADASYNtrain,yRBFSVM20ADASYNtrain,~,aucRBFSVM20ADASYNtrain] = perfcurve(targetsRBFSVM20ADASYNtrain_all,scoresRBFSVM20ADASYNtrain_all,1);
[xRBFSVM20ADASYNtest,yRBFSVM20ADASYNtest,~,aucRBFSVM20ADASYNtest] = perfcurve(targetsRBFSVM20ADASYNtest_all,scoresRBFSVM20ADASYNtest_all,1);

% kNN, 3 neighbors
[x3KNN20ADASYNtrain,y3KNN20ADASYNtrain,~,auc3KNN20ADASYNtrain] = perfcurve(targets3KNN20ADASYNtrain_all,scores3KNN20ADASYNtrain_all,1);
[x3KNN20ADASYNtest,y3KNN20ADASYNtest,~,auc3KNN20ADASYNtest] = perfcurve(targets3KNN20ADASYNtest_all,scores3KNN20ADASYNtest_all,1);

% kNN, 5 neighbors
[x5KNN20ADASYNtrain,y5KNN20ADASYNtrain,~,auc5KNN20ADASYNtrain] = perfcurve(targets5KNN20ADASYNtrain_all,scores5KNN20ADASYNtrain_all,1);
[x5KNN20ADASYNtest,y5KNN20ADASYNtest,~,auc5KNN20ADASYNtest] = perfcurve(targets5KNN20ADASYNtest_all,scores5KNN20ADASYNtest_all,1);

% kNN, 7 neighbors
[x7KNN20ADASYNtrain,y7KNN20ADASYNtrain,~,auc7KNN20ADASYNtrain] = perfcurve(targets7KNN20ADASYNtrain_all,scores7KNN20ADASYNtrain_all,1);
[x7KNN20ADASYNtest,y7KNN20ADASYNtest,~,auc7KNN20ADASYNtest] = perfcurve(targets7KNN20ADASYNtest_all,scores7KNN20ADASYNtest_all,1);

% kNN, 9 neighbors
[x9KNN20ADASYNtrain,y9KNN20ADASYNtrain,~,auc9KNN20ADASYNtrain] = perfcurve(targets9KNN20ADASYNtrain_all,scores9KNN20ADASYNtrain_all,1);
[x9KNN20ADASYNtest,y9KNN20ADASYNtest,~,auc9KNN20ADASYNtest] = perfcurve(targets9KNN20ADASYNtest_all,scores9KNN20ADASYNtest_all,1);

% RF, 5 Trees
[x5Tree20ADASYNtrain,y5Tree20ADASYNtrain,~,auc5Tree20ADASYNtrain] = perfcurve(targets5Tree20ADASYNtrain_all,scores5Tree20ADASYNtrain_all,1);
[x5Tree20ADASYNtest,y5Tree20ADASYNtest,~,auc5Tree20ADASYNtest] = perfcurve(targets5Tree20ADASYNtest_all,scores5Tree20ADASYNtest_all,1);

% RF, 10 Trees
[x10Tree20ADASYNtrain,y10Tree20ADASYNtrain,~,auc10Tree20ADASYNtrain] = perfcurve(targets10Tree20ADASYNtrain_all,scores10Tree20ADASYNtrain_all,1);
[x10Tree20ADASYNtest,y10Tree20ADASYNtest,~,auc10Tree20ADASYNtest] = perfcurve(targets10Tree20ADASYNtest_all,scores10Tree20ADASYNtest_all,1);

% RF, 20 Trees
[x20Tree20ADASYNtrain,y20Tree20ADASYNtrain,~,auc20Tree20ADASYNtrain] = perfcurve(targets20Tree20ADASYNtrain_all,scores20Tree20ADASYNtrain_all,1);
[x20Tree20ADASYNtest,y20Tree20ADASYNtest,~,auc20Tree20ADASYNtest] = perfcurve(targets20Tree20ADASYNtest_all,scores20Tree20ADASYNtest_all,1);

% RF, 30 Trees
[x30Tree20ADASYNtrain,y30Tree20ADASYNtrain,~,auc30Tree20ADASYNtrain] = perfcurve(targets30Tree20ADASYNtrain_all,scores30Tree20ADASYNtrain_all,1);
[x30Tree20ADASYNtest,y30Tree20ADASYNtest,~,auc30Tree20ADASYNtest] = perfcurve(targets30Tree20ADASYNtest_all,scores30Tree20ADASYNtest_all,1);

% RF, 40 Trees
[x40Tree20ADASYNtrain,y40Tree20ADASYNtrain,~,auc40Tree20ADASYNtrain] = perfcurve(targets40Tree20ADASYNtrain_all,scores40Tree20ADASYNtrain_all,1);
[x40Tree20ADASYNtest,y40Tree20ADASYNtest,~,auc40Tree20ADASYNtest] = perfcurve(targets40Tree20ADASYNtest_all,scores40Tree20ADASYNtest_all,1);

% RF, 50 Trees
[x50Tree20ADASYNtrain,y50Tree20ADASYNtrain,~,auc50Tree20ADASYNtrain] = perfcurve(targets50Tree20ADASYNtrain_all,scores50Tree20ADASYNtrain_all,1);
[x50Tree20ADASYNtest,y50Tree20ADASYNtest,~,auc50Tree20ADASYNtest] = perfcurve(targets50Tree20ADASYNtest_all,scores50Tree20ADASYNtest_all,1);

% Confusion matrices
figure()
subplot(121)
confusionchart(targetsLinSVM20ADASYNtrain_all,predsLinSVM20ADASYNtrain_all);
title('Linear SVM, training')
subplot(122)
confusionchart(targetsLinSVM20ADASYNtest_all,predsLinSVM20ADASYNtest_all);
title('Linear SVM, validation')

figure()
subplot(121)
confusionchart(targetsQuadSVM20ADASYNtrain_all,predsQuadSVM20ADASYNtrain_all);
title('Quadratic SVM, training')
subplot(122)
confusionchart(targetsQuadSVM20ADASYNtest_all,predsQuadSVM20ADASYNtest_all);
title('Quadratic SVM, validation')

figure()
subplot(121)
confusionchart(targetsCubicSVM20ADASYNtrain_all,predsCubicSVM20ADASYNtrain_all);
title('Cubic SVM, training')
subplot(122)
confusionchart(targetsCubicSVM20ADASYNtest_all,predsCubicSVM20ADASYNtest_all);
title('Cubic SVM, validation')

figure()
subplot(121)
confusionchart(targetsRBFSVM20ADASYNtrain_all,predsRBFSVM20ADASYNtrain_all);
title('RBF SVM, training')
subplot(122)
confusionchart(targetsRBFSVM20ADASYNtest_all,predsRBFSVM20ADASYNtest_all);
title('RBF SVM, validation')

figure()
subplot(121)
confusionchart(targets3KNN20ADASYNtrain_all,preds3KNN20ADASYNtrain_all);
title('kNN - k = 3, training')
subplot(122)
confusionchart(targets3KNN20ADASYNtest_all,preds3KNN20ADASYNtest_all);
title('kNN - k = 3, validation')

figure()
subplot(121)
confusionchart(targets5KNN20ADASYNtrain_all,preds5KNN20ADASYNtrain_all);
title('kNN - k = 5, training')
subplot(122)
confusionchart(targets5KNN20ADASYNtest_all,preds5KNN20ADASYNtest_all);
title('kNN - k = 5, validation')

figure()
subplot(121)
confusionchart(targets7KNN20ADASYNtrain_all,preds7KNN20ADASYNtrain_all);
title('kNN - k = 7, training')
subplot(122)
confusionchart(targets7KNN20ADASYNtest_all,preds7KNN20ADASYNtest_all);
title('kNN - k = 7, validation')

figure()
subplot(121)
confusionchart(targets9KNN20ADASYNtrain_all,preds9KNN20ADASYNtrain_all);
title('kNN - k = 9, training')
subplot(122)
confusionchart(targets9KNN20ADASYNtest_all,preds9KNN20ADASYNtest_all);
title('kNN - k = 9, validation')

figure()
subplot(121)
confusionchart(targets5Tree20ADASYNtrain_all,preds5Tree20ADASYNtrain_all);
title('RF 5 Trees, training')
subplot(122)
confusionchart(targets5Tree20ADASYNtest_all,preds5Tree20ADASYNtest_all);
title('RF 5 Trees, validation')

figure()
subplot(121)
confusionchart(targets10Tree20ADASYNtrain_all,preds10Tree20ADASYNtrain_all);
title('RF 10 Trees, training')
subplot(122)
confusionchart(targets10Tree20ADASYNtest_all,preds10Tree20ADASYNtest_all);
title('RF 10 Trees, validation')

figure()
subplot(121)
confusionchart(targets20Tree20ADASYNtrain_all,preds20Tree20ADASYNtrain_all);
title('RF 20 Trees, training')
subplot(122)
confusionchart(targets20Tree20ADASYNtest_all,preds20Tree20ADASYNtest_all);
title('RF 20 Trees, validation')

figure()
subplot(121)
confusionchart(targets30Tree20ADASYNtrain_all,preds30Tree20ADASYNtrain_all);
title('RF 30 Trees, training')
subplot(122)
confusionchart(targets30Tree20ADASYNtest_all,preds30Tree20ADASYNtest_all);
title('RF 30 Trees, validation')

figure()
subplot(121)
confusionchart(targets40Tree20ADASYNtrain_all,preds40Tree20ADASYNtrain_all);
title('RF 40 Trees, training')
subplot(122)
confusionchart(targets40Tree20ADASYNtest_all,preds40Tree20ADASYNtest_all);
title('RF 40 Trees, validation')

figure()
subplot(121)
confusionchart(targets50Tree20ADASYNtrain_all,preds50Tree20ADASYNtrain_all);
title('RF 50 Trees, training')
subplot(122)
confusionchart(targets50Tree20ADASYNtest_all,preds50Tree20ADASYNtest_all);
title('RF 50 Trees, validation')


% % ROC curve plots, training and validation
figure()
plot(xLinSVM20ADASYNtrain,yLinSVM20ADASYNtrain,'LineWidth',2)
hold on
plot(xLinSVM20ADASYNtest,yLinSVM20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, Linear SVM')
legend('Training', 'Validation')
hold off

figure()
plot(xQuadSVM20ADASYNtrain,yQuadSVM20ADASYNtrain,'LineWidth',2)
hold on
plot(xQuadSVM20ADASYNtest,yQuadSVM20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, Quadratic SVM')
legend('Training', 'Validation')
hold off

figure()
plot(xCubicSVM20ADASYNtrain,yCubicSVM20ADASYNtrain,'LineWidth',2)
hold on
plot(xCubicSVM20ADASYNtest,yCubicSVM20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, Cubic SVM')
legend('Training', 'Validation')
hold off

figure()
plot(xRBFSVM20ADASYNtrain,yRBFSVM20ADASYNtrain,'LineWidth',2)
hold on
plot(xRBFSVM20ADASYNtest,yRBFSVM20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RBF SVM')
legend('Training', 'Validation')
hold off

figure()
plot(x3KNN20ADASYNtrain,y3KNN20ADASYNtrain,'LineWidth',2)
hold on
plot(x3KNN20ADASYNtest,y3KNN20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 3')
legend('Training', 'Validation')
hold off

figure()
plot(x5KNN20ADASYNtrain,y5KNN20ADASYNtrain,'LineWidth',2)
hold on
plot(x5KNN20ADASYNtest,y5KNN20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 5')
legend('Training', 'Validation')
hold off

figure()
plot(x7KNN20ADASYNtrain,y7KNN20ADASYNtrain,'LineWidth',2)
hold on
plot(x7KNN20ADASYNtest,y7KNN20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 7')
legend('Training', 'Validation')
hold off

figure()
plot(x9KNN20ADASYNtrain,y9KNN20ADASYNtrain,'LineWidth',2)
hold on
plot(x9KNN20ADASYNtest,y9KNN20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 9')
legend('Training', 'Validation')
hold off

figure()
plot(x5Tree20ADASYNtrain,y5Tree20ADASYNtrain,'LineWidth',2)
hold on
plot(x5Tree20ADASYNtest,y5Tree20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 5 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x10Tree20ADASYNtrain,y10Tree20ADASYNtrain,'LineWidth',2)
hold on
plot(x10Tree20ADASYNtest,y10Tree20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 10 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x20Tree20ADASYNtrain,y20Tree20ADASYNtrain,'LineWidth',2)
hold on
plot(x20Tree20ADASYNtest,y20Tree20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 20 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x30Tree20ADASYNtrain,y30Tree20ADASYNtrain,'LineWidth',2)
hold on
plot(x30Tree20ADASYNtest,y30Tree20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 30 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x40Tree20ADASYNtrain,y40Tree20ADASYNtrain,'LineWidth',2)
hold on
plot(x40Tree20ADASYNtest,y40Tree20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 40 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x50Tree20ADASYNtrain,y50Tree20ADASYNtrain,'LineWidth',2)
hold on
plot(x50Tree20ADASYNtest,y50Tree20ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 50 Trees')
legend('Training', 'Validation')
hold off


% ROC curve plots, validation only, all models.
figure()
plot(xLinSVM20ADASYNtest,yLinSVM20ADASYNtest,'r','LineWidth',2)
hold on
plot(xQuadSVM20ADASYNtest,yQuadSVM20ADASYNtest,'g','LineWidth',2)
plot(xCubicSVM20ADASYNtest,yCubicSVM20ADASYNtest,'b','LineWidth',2)
plot(xRBFSVM20ADASYNtest,yRBFSVM20ADASYNtest,'c','LineWidth',2)
plot(x3KNN20ADASYNtest,y3KNN20ADASYNtest,'m','LineWidth',2)
plot(x5KNN20ADASYNtest,y5KNN20ADASYNtest,'y','LineWidth',2)
plot(x7KNN20ADASYNtest,y7KNN20ADASYNtest,'k','LineWidth',2)
plot(x9KNN20ADASYNtest,y9KNN20ADASYNtest,'r--','LineWidth',2)
plot(x5Tree20ADASYNtest,y5Tree20ADASYNtest,'g--','LineWidth',2)
plot(x10Tree20ADASYNtest,y10Tree20ADASYNtest,'b--','LineWidth',2)
plot(x20Tree20ADASYNtest,y20Tree20ADASYNtest,'c--','LineWidth',2)
plot(x30Tree20ADASYNtest,y30Tree20ADASYNtest,'m--','LineWidth',2)
plot(x40Tree20ADASYNtest,y40Tree20ADASYNtest,'y--','LineWidth',2)
plot(x50Tree20ADASYNtest,y50Tree20ADASYNtest,'k--','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, all models, validation only')
legend('Linear SVM', 'Quadratic SVM','Cubic SVM','RBF SVM','kNN, k=3',...
    'kNN, k=5','kNN, k=7','kNN, k=9','RF, 5 Trees', 'RF, 10 Trees',...
    'RF, 20 Trees','RF, 30 Trees','RF, 40 Trees', 'RF, 50 Trees','Location','SouthEast')

AUCtrain = [aucLinSVM20ADASYNtrain;aucQuadSVM20ADASYNtrain;aucCubicSVM20ADASYNtrain;aucRBFSVM20ADASYNtrain;...
    auc3KNN20ADASYNtrain;auc5KNN20ADASYNtrain;auc7KNN20ADASYNtrain;auc9KNN20ADASYNtrain;auc5Tree20ADASYNtrain;...
    auc10Tree20ADASYNtrain;auc20Tree20ADASYNtrain;auc30Tree20ADASYNtrain;auc40Tree20ADASYNtrain;...
    auc50Tree20ADASYNtrain];

AUCtest = [aucLinSVM20ADASYNtest;aucQuadSVM20ADASYNtest;aucCubicSVM20ADASYNtest;aucRBFSVM20ADASYNtest;...
    auc3KNN20ADASYNtest;auc5KNN20ADASYNtest;auc7KNN20ADASYNtest;auc9KNN20ADASYNtest;auc5Tree20ADASYNtest;...
    auc10Tree20ADASYNtest;auc20Tree20ADASYNtest;auc30Tree20ADASYNtest;auc40Tree20ADASYNtest;...
    auc50Tree20ADASYNtest];

meanTime = [m1;m2;m3;m4;m5;m6;m7;m8;m9;m10;m11;m12;m13;m14];
totalTime = [s1;s2;s3;s4;s5;s6;s7;s8;s9;s10;s11;s12;s13;s14];

T = table(AUCtrain,AUCtest,meanTime,totalTime);

function T = trainClassifier60ADASYN(trainingData)

indices = crossvalind('Kfold',trainingData(:,end),10);

% Linear SVM
targetsLinSVM60ADASYNtrain_all = [];
predsLinSVM60ADASYNtrain_all = [];
scoresLinSVM60ADASYNtrain_all = [];

targetsLinSVM60ADASYNtest_all = [];
predsLinSVM60ADASYNtest_all = [];
scoresLinSVM60ADASYNtest_all = [];

% Quadratic SVM
targetsQuadSVM60ADASYNtrain_all = [];
predsQuadSVM60ADASYNtrain_all = [];
scoresQuadSVM60ADASYNtrain_all = [];

targetsQuadSVM60ADASYNtest_all = [];
predsQuadSVM60ADASYNtest_all = [];
scoresQuadSVM60ADASYNtest_all = [];

% Cubic SVM
targetsCubicSVM60ADASYNtrain_all = [];
predsCubicSVM60ADASYNtrain_all = [];
scoresCubicSVM60ADASYNtrain_all = [];

targetsCubicSVM60ADASYNtest_all = [];
predsCubicSVM60ADASYNtest_all = [];
scoresCubicSVM60ADASYNtest_all = [];

% RBF SVM
targetsRBFSVM60ADASYNtrain_all = [];
predsRBFSVM60ADASYNtrain_all = [];
scoresRBFSVM60ADASYNtrain_all = [];

targetsRBFSVM60ADASYNtest_all = [];
predsRBFSVM60ADASYNtest_all = [];
scoresRBFSVM60ADASYNtest_all = [];

% 3kNN
targets3KNN60ADASYNtrain_all = [];
preds3KNN60ADASYNtrain_all = [];
scores3KNN60ADASYNtrain_all = [];

targets3KNN60ADASYNtest_all = [];
preds3KNN60ADASYNtest_all = [];
scores3KNN60ADASYNtest_all = [];

% 5kNN
targets5KNN60ADASYNtrain_all = [];
preds5KNN60ADASYNtrain_all = [];
scores5KNN60ADASYNtrain_all = [];

targets5KNN60ADASYNtest_all = [];
preds5KNN60ADASYNtest_all = [];
scores5KNN60ADASYNtest_all = [];

% 7 kNN
targets7KNN60ADASYNtrain_all = [];
preds7KNN60ADASYNtrain_all = [];
scores7KNN60ADASYNtrain_all = [];

targets7KNN60ADASYNtest_all = [];
preds7KNN60ADASYNtest_all = [];
scores7KNN60ADASYNtest_all = [];

% 9 kNN
targets9KNN60ADASYNtrain_all = [];
preds9KNN60ADASYNtrain_all = [];
scores9KNN60ADASYNtrain_all = [];

targets9KNN60ADASYNtest_all = [];
preds9KNN60ADASYNtest_all = [];
scores9KNN60ADASYNtest_all = [];

% RF, 5 Trees
targets5Tree60ADASYNtrain_all = [];
preds5Tree60ADASYNtrain_all = [];
scores5Tree60ADASYNtrain_all = [];

targets5Tree60ADASYNtest_all = [];
preds5Tree60ADASYNtest_all = [];
scores5Tree60ADASYNtest_all = [];

% RF, 10 Trees
targets10Tree60ADASYNtrain_all = [];
preds10Tree60ADASYNtrain_all = [];
scores10Tree60ADASYNtrain_all = [];

targets10Tree60ADASYNtest_all = [];
preds10Tree60ADASYNtest_all = [];
scores10Tree60ADASYNtest_all = [];

% RF, 20 Trees
targets20Tree60ADASYNtrain_all = [];
preds20Tree60ADASYNtrain_all = [];
scores20Tree60ADASYNtrain_all = [];

targets20Tree60ADASYNtest_all = [];
preds20Tree60ADASYNtest_all = [];
scores20Tree60ADASYNtest_all = [];

% RF, 30 Trees
targets30Tree60ADASYNtrain_all = [];
preds30Tree60ADASYNtrain_all = [];
scores30Tree60ADASYNtrain_all = [];

targets30Tree60ADASYNtest_all = [];
preds30Tree60ADASYNtest_all = [];
scores30Tree60ADASYNtest_all = [];

% RF, 40 Trees
targets40Tree60ADASYNtrain_all = [];
preds40Tree60ADASYNtrain_all = [];
scores40Tree60ADASYNtrain_all = [];

targets40Tree60ADASYNtest_all = [];
preds40Tree60ADASYNtest_all = [];
scores40Tree60ADASYNtest_all = [];

% RF, 50 Trees
targets50Tree60ADASYNtrain_all = [];
preds50Tree60ADASYNtrain_all = [];
scores50Tree60ADASYNtrain_all = [];

targets50Tree60ADASYNtest_all = [];
preds50Tree60ADASYNtest_all = [];
scores50Tree60ADASYNtest_all = [];

for i = 1:10
    test = (indices == i); 
    train = ~test;
    
    % Linear SVM
    tic
    classificationLinearSVM60ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'linear', ...
    'PolynomialOrder', [], ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);

    % Training
    [predsLinSVM60ADASYNtrain,~] = predict(classificationLinearSVM60ADASYN,trainingData(train,1:end-1));
    t1{1,i} = toc;
    targetsLinSVM60ADASYNtrain = trainingData(train,end);
    targetsLinSVM60ADASYNtrain_all = [targetsLinSVM60ADASYNtrain_all; squeeze(targetsLinSVM60ADASYNtrain)];
    predsLinSVM60ADASYNtrain_all = [predsLinSVM60ADASYNtrain_all; squeeze(predsLinSVM60ADASYNtrain)];
    
    [~,scoresLinSVM60ADASYN] = resubPredict(fitPosterior(classificationLinearSVM60ADASYN));
    scoresLinSVM60ADASYNtrain_all = [scoresLinSVM60ADASYNtrain_all;scoresLinSVM60ADASYN(:,2)];
    
    % Validation
    [predsLinSVM60ADASYNtest,scoresLinSVM60ADASYNtest] = predict(classificationLinearSVM60ADASYN,trainingData(test,1:end-1));
    targetsLinSVM60ADASYNtest = trainingData(test,end);
    targetsLinSVM60ADASYNtest_all = [targetsLinSVM60ADASYNtest_all; squeeze(targetsLinSVM60ADASYNtest)];
    predsLinSVM60ADASYNtest_all = [predsLinSVM60ADASYNtest_all; squeeze(predsLinSVM60ADASYNtest)];
    
    scoresLinSVM60ADASYNtest_all = [scoresLinSVM60ADASYNtest_all; scoresLinSVM60ADASYNtest(:,2)];
    
    
    % Quadratic SVM
    tic
    classificationQuadSVM60ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'polynomial', ...
    'PolynomialOrder', 2, ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);

    % Training
    [predsQuadSVM60ADASYNtrain,~] = predict(classificationQuadSVM60ADASYN,trainingData(train,1:end-1));
    t2{1,i} = toc;
    targetsQuadSVM60ADASYNtrain = trainingData(train,end);
    targetsQuadSVM60ADASYNtrain_all = [targetsQuadSVM60ADASYNtrain_all; squeeze(targetsQuadSVM60ADASYNtrain)];
    predsQuadSVM60ADASYNtrain_all = [predsQuadSVM60ADASYNtrain_all; squeeze(predsQuadSVM60ADASYNtrain)];
    
    [~,scoresQuadSVM60ADASYN] = resubPredict(fitPosterior(classificationQuadSVM60ADASYN));
    scoresQuadSVM60ADASYNtrain_all = [scoresQuadSVM60ADASYNtrain_all; scoresQuadSVM60ADASYN(:,2)];
    
    % Validation
    [predsQuadSVM60ADASYNtest,scoresQuadSVM60ADASYNtest] = predict(classificationQuadSVM60ADASYN,trainingData(test,1:end-1));
    targetsQuadSVM60ADASYNtest = trainingData(test,end);
    targetsQuadSVM60ADASYNtest_all = [targetsQuadSVM60ADASYNtest_all; squeeze(targetsQuadSVM60ADASYNtest)];
    predsQuadSVM60ADASYNtest_all = [predsQuadSVM60ADASYNtest_all; squeeze(predsQuadSVM60ADASYNtest)];
    
    scoresQuadSVM60ADASYNtest_all = [scoresQuadSVM60ADASYNtest_all; scoresQuadSVM60ADASYNtest(:,2)];
    
    
    % Cubic SVM
    tic
    classificationCubicSVM60ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'polynomial', ...
    'PolynomialOrder', 3, ...
    'KernelScale', 'auto', ...
    'BoxConstraint', 1, ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);

    % Training
    [predsCubicSVM60ADASYNtrain,~] = predict(classificationCubicSVM60ADASYN,trainingData(train,1:end-1));
    t3{1,i} = toc;
    targetsCubicSVM60ADASYNtrain = trainingData(train,end);
    targetsCubicSVM60ADASYNtrain_all = [targetsCubicSVM60ADASYNtrain_all; squeeze(targetsCubicSVM60ADASYNtrain)];
    predsCubicSVM60ADASYNtrain_all = [predsCubicSVM60ADASYNtrain_all; squeeze(predsCubicSVM60ADASYNtrain)];
    
    [~,scoresCubicSVM60ADASYN] = resubPredict(fitPosterior(classificationCubicSVM60ADASYN));
    scoresCubicSVM60ADASYNtrain_all = [scoresCubicSVM60ADASYNtrain_all; scoresCubicSVM60ADASYN(:,2)];    
    
    % Validation
    [predsCubicSVM60ADASYNtest,scoresCubicSVM60ADASYNtest] = predict(classificationCubicSVM60ADASYN,trainingData(test,1:end-1));
    targetsCubicSVM60ADASYNtest = trainingData(test,end);
    targetsCubicSVM60ADASYNtest_all = [targetsCubicSVM60ADASYNtest_all; squeeze(targetsCubicSVM60ADASYNtest)];
    predsCubicSVM60ADASYNtest_all = [predsCubicSVM60ADASYNtest_all; squeeze(predsCubicSVM60ADASYNtest)];
    
    scoresCubicSVM60ADASYNtest_all = [scoresCubicSVM60ADASYNtest_all; scoresCubicSVM60ADASYNtest(:,2)];
    
    
    % RBF SVM
    tic
    classificationRBFSVM60ADASYN = fitcsvm(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'KernelFunction', 'RBF', ...
    'PolynomialOrder', [], ...
    'KernelScale', 'auto', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);
    
    % Training
    [predsRBFSVM60ADASYNtrain,~] = predict(classificationRBFSVM60ADASYN,trainingData(train,1:end-1));
    t4{1,i} = toc;
    targetsRBFSVM60ADASYNtrain = trainingData(train,end);
    targetsRBFSVM60ADASYNtrain_all = [targetsRBFSVM60ADASYNtrain_all; squeeze(targetsRBFSVM60ADASYNtrain)];
    predsRBFSVM60ADASYNtrain_all = [predsRBFSVM60ADASYNtrain_all; squeeze(predsRBFSVM60ADASYNtrain)];
    
    [~,scoresRBFSVM60ADASYN] = resubPredict(fitPosterior(classificationRBFSVM60ADASYN));
    scoresRBFSVM60ADASYNtrain_all = [scoresRBFSVM60ADASYNtrain_all; scoresRBFSVM60ADASYN(:,2)];    
    
    % Validation
    [predsRBFSVM60ADASYNtest,scoresRBFSVM60ADASYNtest] = predict(classificationRBFSVM60ADASYN,trainingData(test,1:end-1));
    targetsRBFSVM60ADASYNtest = trainingData(test,end);
    targetsRBFSVM60ADASYNtest_all = [targetsRBFSVM60ADASYNtest_all; squeeze(targetsRBFSVM60ADASYNtest)];
    predsRBFSVM60ADASYNtest_all = [predsRBFSVM60ADASYNtest_all; squeeze(predsRBFSVM60ADASYNtest)];
    
    scoresRBFSVM60ADASYNtest_all = [scoresRBFSVM60ADASYNtest_all; scoresRBFSVM60ADASYNtest(:,2)];
    
    
    % kNN, 3 neighbors
    tic
    classification3KNN60ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 3, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds3KNN60ADASYNtrain,~] = predict(classification3KNN60ADASYN,trainingData(train,1:end-1));
    t5{1,i} = toc;
    targets3KNN60ADASYNtrain = trainingData(train,end);
    targets3KNN60ADASYNtrain_all = [targets3KNN60ADASYNtrain_all; squeeze(targets3KNN60ADASYNtrain)];
    preds3KNN60ADASYNtrain_all = [preds3KNN60ADASYNtrain_all; squeeze(preds3KNN60ADASYNtrain)];
    
    [~,scores3KNN60ADASYN] = resubPredict(classification3KNN60ADASYN);
    scores3KNN60ADASYNtrain_all = [scores3KNN60ADASYNtrain_all; scores3KNN60ADASYN(:,2)];    
    
    % Validation
    [preds3KNN60ADASYNtest,scores3KNN60ADASYNtest] = predict(classification3KNN60ADASYN,trainingData(test,1:end-1));
    targets3KNN60ADASYNtest = trainingData(test,end);
    targets3KNN60ADASYNtest_all = [targets3KNN60ADASYNtest_all; squeeze(targets3KNN60ADASYNtest)];
    preds3KNN60ADASYNtest_all = [preds3KNN60ADASYNtest_all; squeeze(preds3KNN60ADASYNtest)];
    
    scores3KNN60ADASYNtest_all = [scores3KNN60ADASYNtest_all; scores3KNN60ADASYNtest(:,2)];
    
    
    % kNN, 5 neighbors
    tic
    classification5KNN60ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 5, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds5KNN60ADASYNtrain,~] = predict(classification5KNN60ADASYN,trainingData(train,1:end-1));
    t6{1,i} = toc;
    targets5KNN60ADASYNtrain = trainingData(train,end);
    targets5KNN60ADASYNtrain_all = [targets5KNN60ADASYNtrain_all; squeeze(targets5KNN60ADASYNtrain)];
    preds5KNN60ADASYNtrain_all = [preds5KNN60ADASYNtrain_all; squeeze(preds5KNN60ADASYNtrain)];
    
    [~,scores5KNN60ADASYN] = resubPredict(classification5KNN60ADASYN);
    scores5KNN60ADASYNtrain_all = [scores5KNN60ADASYNtrain_all; scores5KNN60ADASYN(:,2)];    
    
    % Validation
    [preds5KNN60ADASYNtest,scores5KNN60ADASYNtest] = predict(classification5KNN60ADASYN,trainingData(test,1:end-1));
    targets5KNN60ADASYNtest = trainingData(test,end);
    targets5KNN60ADASYNtest_all = [targets5KNN60ADASYNtest_all; squeeze(targets5KNN60ADASYNtest)];
    preds5KNN60ADASYNtest_all = [preds5KNN60ADASYNtest_all; squeeze(preds5KNN60ADASYNtest)];
    
    scores5KNN60ADASYNtest_all = [scores5KNN60ADASYNtest_all; scores5KNN60ADASYNtest(:,2)];
    
    
    % kNN, 7 neighbors
    tic
    classification7KNN60ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 7, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds7KNN60ADASYNtrain,~] = predict(classification7KNN60ADASYN,trainingData(train,1:end-1));
    t7{1,i} = toc;
    targets7KNN60ADASYNtrain = trainingData(train,end);
    targets7KNN60ADASYNtrain_all = [targets7KNN60ADASYNtrain_all; squeeze(targets7KNN60ADASYNtrain)];
    preds7KNN60ADASYNtrain_all = [preds7KNN60ADASYNtrain_all; squeeze(preds7KNN60ADASYNtrain)];
    
    [~,scores7KNN60ADASYN] = resubPredict(classification7KNN60ADASYN);
    scores7KNN60ADASYNtrain_all = [scores7KNN60ADASYNtrain_all; scores7KNN60ADASYN(:,2)];    
    
    % Validation
    [preds7KNN60ADASYNtest,scores7KNN60ADASYNtest] = predict(classification7KNN60ADASYN,trainingData(test,1:end-1));
    targets7KNN60ADASYNtest = trainingData(test,end);
    targets7KNN60ADASYNtest_all = [targets7KNN60ADASYNtest_all; squeeze(targets7KNN60ADASYNtest)];
    preds7KNN60ADASYNtest_all = [preds7KNN60ADASYNtest_all; squeeze(preds7KNN60ADASYNtest)];
    
    scores7KNN60ADASYNtest_all = [scores7KNN60ADASYNtest_all; scores7KNN60ADASYNtest(:,2)];
    
    
    % kNN, 9 neighbors
    tic
    classification9KNN60ADASYN = fitcknn(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'Distance', 'Euclidean', ...
    'Exponent', [], ...
    'NumNeighbors', 9, ...
    'DistanceWeight', 'Equal', ...
    'Standardize', true, ...
    'ClassNames', [0; 1]);


    % Training
    [preds9KNN60ADASYNtrain,~] = predict(classification9KNN60ADASYN,trainingData(train,1:end-1));
    t8{1,i} = toc;
    targets9KNN60ADASYNtrain = trainingData(train,end);
    targets9KNN60ADASYNtrain_all = [targets9KNN60ADASYNtrain_all; squeeze(targets9KNN60ADASYNtrain)];
    preds9KNN60ADASYNtrain_all = [preds9KNN60ADASYNtrain_all; squeeze(preds9KNN60ADASYNtrain)];
    
    [~,scores9KNN60ADASYN] = resubPredict(classification9KNN60ADASYN);
    scores9KNN60ADASYNtrain_all = [scores9KNN60ADASYNtrain_all; scores9KNN60ADASYN(:,2)];    
    
    % Validation
    [preds9KNN60ADASYNtest,scores9KNN60ADASYNtest] = predict(classification9KNN60ADASYN,trainingData(test,1:end-1));
    targets9KNN60ADASYNtest = trainingData(test,end);
    targets9KNN60ADASYNtest_all = [targets9KNN60ADASYNtest_all; squeeze(targets9KNN60ADASYNtest)];
    preds9KNN60ADASYNtest_all = [preds9KNN60ADASYNtest_all; squeeze(preds9KNN60ADASYNtest)];
    
    scores9KNN60ADASYNtest_all = [scores9KNN60ADASYNtest_all; scores9KNN60ADASYNtest(:,2)];
    
    
    % RF, 5 Trees
    tic
    classification5Tree60ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 5, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds5Tree60ADASYNtrain,~] = predict(classification5Tree60ADASYN,trainingData(train,1:end-1));
    t9{1,i} = toc;
    targets5Tree60ADASYNtrain = trainingData(train,end);
    targets5Tree60ADASYNtrain_all = [targets5Tree60ADASYNtrain_all; squeeze(targets5Tree60ADASYNtrain)];
    preds5Tree60ADASYNtrain_all = [preds5Tree60ADASYNtrain_all; squeeze(preds5Tree60ADASYNtrain)];
    
    [~,scores5Tree60ADASYN] = resubPredict(classification5Tree60ADASYN);
    scores5Tree60ADASYNtrain_all = [scores5Tree60ADASYNtrain_all; scores5Tree60ADASYN(:,2)];    
    
    % Validation
    [preds5Tree60ADASYNtest,scores5Tree60ADASYNtest] = predict(classification5Tree60ADASYN,trainingData(test,1:end-1));
    targets5Tree60ADASYNtest = trainingData(test,end);
    targets5Tree60ADASYNtest_all = [targets5Tree60ADASYNtest_all; squeeze(targets5Tree60ADASYNtest)];
    preds5Tree60ADASYNtest_all = [preds5Tree60ADASYNtest_all; squeeze(preds5Tree60ADASYNtest)];
    
    scores5Tree60ADASYNtest_all = [scores5Tree60ADASYNtest_all; scores5Tree60ADASYNtest(:,2)];
    
    
    
    % RF, 10 Trees
    tic
    classification10Tree60ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 10, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds10Tree60ADASYNtrain,~] = predict(classification10Tree60ADASYN,trainingData(train,1:end-1));
    t10{1,i} = toc;
    targets10Tree60ADASYNtrain = trainingData(train,end);
    targets10Tree60ADASYNtrain_all = [targets10Tree60ADASYNtrain_all; squeeze(targets10Tree60ADASYNtrain)];
    preds10Tree60ADASYNtrain_all = [preds10Tree60ADASYNtrain_all; squeeze(preds10Tree60ADASYNtrain)];
    
    [~,scores10Tree60ADASYN] = resubPredict(classification10Tree60ADASYN);
    scores10Tree60ADASYNtrain_all = [scores10Tree60ADASYNtrain_all; scores10Tree60ADASYN(:,2)];      
    
    % Validation
    [preds10Tree60ADASYNtest,scores10Tree60ADASYNtest] = predict(classification10Tree60ADASYN,trainingData(test,1:end-1));
    targets10Tree60ADASYNtest = trainingData(test,end);
    targets10Tree60ADASYNtest_all = [targets10Tree60ADASYNtest_all; squeeze(targets10Tree60ADASYNtest)];
    preds10Tree60ADASYNtest_all = [preds10Tree60ADASYNtest_all; squeeze(preds10Tree60ADASYNtest)];
    
    scores10Tree60ADASYNtest_all = [scores10Tree60ADASYNtest_all; scores10Tree60ADASYNtest(:,2)];
    
    
    
    % RF, 20 Trees
    tic
    classification20Tree60ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 20, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds20Tree60ADASYNtrain,~] = predict(classification20Tree60ADASYN,trainingData(train,1:end-1));
    t11{1,i} = toc;
    targets20Tree60ADASYNtrain = trainingData(train,end);
    targets20Tree60ADASYNtrain_all = [targets20Tree60ADASYNtrain_all; squeeze(targets20Tree60ADASYNtrain)];
    preds20Tree60ADASYNtrain_all = [preds20Tree60ADASYNtrain_all; squeeze(preds20Tree60ADASYNtrain)];
    
    [~,scores20Tree60ADASYN] = resubPredict(classification20Tree60ADASYN);
    scores20Tree60ADASYNtrain_all = [scores20Tree60ADASYNtrain_all; scores20Tree60ADASYN(:,2)];    
    
    % Validation
    [preds20Tree60ADASYNtest,scores20Tree60ADASYNtest] = predict(classification20Tree60ADASYN,trainingData(test,1:end-1));
    targets20Tree60ADASYNtest = trainingData(test,end);
    targets20Tree60ADASYNtest_all = [targets20Tree60ADASYNtest_all; squeeze(targets20Tree60ADASYNtest)];
    preds20Tree60ADASYNtest_all = [preds20Tree60ADASYNtest_all; squeeze(preds20Tree60ADASYNtest)];
    
    scores20Tree60ADASYNtest_all = [scores20Tree60ADASYNtest_all; scores20Tree60ADASYNtest(:,2)]; 
    
    
    % RF, 30 Trees
    tic
    classification30Tree60ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 30, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds30Tree60ADASYNtrain,~] = predict(classification30Tree60ADASYN,trainingData(train,1:end-1));
    t12{1,i} = toc;
    targets30Tree60ADASYNtrain = trainingData(train,end);
    targets30Tree60ADASYNtrain_all = [targets30Tree60ADASYNtrain_all; squeeze(targets30Tree60ADASYNtrain)];
    preds30Tree60ADASYNtrain_all = [preds30Tree60ADASYNtrain_all; squeeze(preds30Tree60ADASYNtrain)];
    
    [~,scores30Tree60ADASYN] = resubPredict(classification30Tree60ADASYN);
    scores30Tree60ADASYNtrain_all = [scores30Tree60ADASYNtrain_all; scores30Tree60ADASYN(:,2)];    
    
    % Validation
    [preds30Tree60ADASYNtest,scores30Tree60ADASYNtest] = predict(classification30Tree60ADASYN,trainingData(test,1:end-1));
    targets30Tree60ADASYNtest = trainingData(test,end);
    targets30Tree60ADASYNtest_all = [targets30Tree60ADASYNtest_all; squeeze(targets30Tree60ADASYNtest)];
    preds30Tree60ADASYNtest_all = [preds30Tree60ADASYNtest_all; squeeze(preds30Tree60ADASYNtest)];
    
    scores30Tree60ADASYNtest_all = [scores30Tree60ADASYNtest_all; scores30Tree60ADASYNtest(:,2)];
    
    
    % RF, 40 Trees
    tic
    classification40Tree60ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 40, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds40Tree60ADASYNtrain,~] = predict(classification40Tree60ADASYN,trainingData(train,1:end-1));
    t13{1,i} = toc;
    targets40Tree60ADASYNtrain = trainingData(train,end);
    targets40Tree60ADASYNtrain_all = [targets40Tree60ADASYNtrain_all; squeeze(targets40Tree60ADASYNtrain)];
    preds40Tree60ADASYNtrain_all = [preds40Tree60ADASYNtrain_all; squeeze(preds40Tree60ADASYNtrain)];
    
    [~,scores40Tree60ADASYN] = resubPredict(classification40Tree60ADASYN);
    scores40Tree60ADASYNtrain_all = [scores40Tree60ADASYNtrain_all; scores40Tree60ADASYN(:,2)];    
    
    % Validation
    [preds40Tree60ADASYNtest,scores40Tree60ADASYNtest] = predict(classification40Tree60ADASYN,trainingData(test,1:end-1));
    targets40Tree60ADASYNtest = trainingData(test,end);
    targets40Tree60ADASYNtest_all = [targets40Tree60ADASYNtest_all; squeeze(targets40Tree60ADASYNtest)];
    preds40Tree60ADASYNtest_all = [preds40Tree60ADASYNtest_all; squeeze(preds40Tree60ADASYNtest)];
    
    scores40Tree60ADASYNtest_all = [scores40Tree60ADASYNtest_all; scores40Tree60ADASYNtest(:,2)];
    
    
    % RF, 50 Trees
    tic
    classification50Tree60ADASYN = fitctree(...
    trainingData(train,1:end-1),...
    trainingData(train,end), ...
    'SplitCriterion', 'gdi', ...
    'MaxNumSplits', 50, ...
    'Surrogate', 'off', ...
    'ClassNames', [0; 1]);

    % Training
    [preds50Tree60ADASYNtrain,~] = predict(classification50Tree60ADASYN,trainingData(train,1:end-1));
    t14{1,i} = toc;
    targets50Tree60ADASYNtrain = trainingData(train,end);
    targets50Tree60ADASYNtrain_all = [targets50Tree60ADASYNtrain_all; squeeze(targets50Tree60ADASYNtrain)];
    preds50Tree60ADASYNtrain_all = [preds50Tree60ADASYNtrain_all; squeeze(preds50Tree60ADASYNtrain)];
    
    [~,scores50Tree60ADASYN] = resubPredict(classification50Tree60ADASYN);
    scores50Tree60ADASYNtrain_all = [scores50Tree60ADASYNtrain_all; scores50Tree60ADASYN(:,2)];    
    
    % Validation
    [preds50Tree60ADASYNtest,scores50Tree60ADASYNtest] = predict(classification50Tree60ADASYN,trainingData(test,1:end-1));
    targets50Tree60ADASYNtest = trainingData(test,end);
    targets50Tree60ADASYNtest_all = [targets50Tree60ADASYNtest_all; squeeze(targets50Tree60ADASYNtest)];
    preds50Tree60ADASYNtest_all = [preds50Tree60ADASYNtest_all; squeeze(preds50Tree60ADASYNtest)];
    
    scores50Tree60ADASYNtest_all = [scores50Tree60ADASYNtest_all; scores50Tree60ADASYNtest(:,2)];
end

save('classificationLinearSVM60ADASYN.mat','classificationLinearSVM60ADASYN','-v7.3'); % majority voting
%save('classificationLinearSVM60ADASYN_30.mat','classificationLinearSVM60ADASYN','-v7.3'); % Threshold 30%
%save('classificationLinearSVM60ADASYN_20.mat','classificationLinearSVM60ADASYN','-v7.3'); % Threshold 20%
%save('classificationLinearSVM60ADASYN_10.mat','classificationLinearSVM60ADASYN','-v7.3'); % Threshold 10%

save('classificationQuadSVM60ADASYN.mat','classificationQuadSVM60ADASYN','-v7.3'); % majority voting
%save('classificationQuadSVM60ADASYN_30.mat','classificationQuadSVM60ADASYN','-v7.3'); % Threshold 30%
%save('classificationQuadSVM60ADASYN_20.mat','classificationQuadSVM60ADASYN','-v7.3'); % Threshold 20%
%save('classificationQuadSVM60ADASYN_10.mat','classificationQuadSVM60ADASYN','-v7.3'); % Threshold 10%

save('classificationCubicSVM60ADASYN.mat','classificationCubicSVM60ADASYN','-v7.3'); % majority voting
%save('classificationCubicSVM60ADASYN_30.mat','classificationCubicSVM60ADASYN','-v7.3'); % Threshold 30%
%save('classificationCubicSVM60ADASYN_20.mat','classificationCubicSVM60ADASYN','-v7.3'); % Threshold 20%
%save('classificationCubicSVM60ADASYN_10.mat','classificationCubicSVM60ADASYN','-v7.3'); % Threshold 10%

save('classificationRBFSVM60ADASYN.mat','classificationRBFSVM60ADASYN','-v7.3'); % majority voting
%save('classificationRBFSVM60ADASYN_30.mat','classificationRBFSVM60ADASYN','-v7.3'); % Threshold 30%
%save('classificationRBFSVM60ADASYN_20.mat','classificationRBFSVM60ADASYN','-v7.3'); % Threshold 20%
%save('classificationRBFSVM60ADASYN_10.mat','classificationRBFSVM60ADASYN','-v7.3'); % Threshold 10%

save('classification3KNN60ADASYN.mat','classification3KNN60ADASYN','-v7.3'); % majority voting
%save('classification3KNN60ADASYN_30.mat','classification3KNN60ADASYN','-v7.3'); % Threshold 30%
%save('classification3KNN60ADASYN_20.mat','classification3KNN60ADASYN','-v7.3'); % Threshold 20%
%save('classification3KNN60ADASYN_10.mat','classification3KNN60ADASYN','-v7.3'); % Threshold 10%

save('classification5KNN60ADASYN.mat','classification5KNN60ADASYN','-v7.3'); % majority voting
%save('classification5KNN60ADASYN_30.mat','classification5KNN60ADASYN','-v7.3'); % Threshold 30%
%save('classification5KNN60ADASYN_20.mat','classification5KNN60ADASYN','-v7.3'); % Threshold 20%
%save('classification5KNN60ADASYN_10.mat','classification5KNN60ADASYN','-v7.3'); % Threshold 10%

save('classification7KNN60ADASYN.mat','classification7KNN60ADASYN','-v7.3'); % majority voting
%save('classification7KNN60ADASYN_30.mat','classification7KNN60ADASYN','-v7.3'); % Threshold 30%
%save('classification7KNN60ADASYN_20.mat','classification7KNN60ADASYN','-v7.3'); % Threshold 20%
%save('classification7KNN60ADASYN_10.mat','classification7KNN60ADASYN','-v7.3'); % Threshold 10%

save('classification9KNN60ADASYN.mat','classification9KNN60ADASYN','-v7.3'); % majority voting
%save('classification9KNN60ADASYN_30.mat','classification9KNN60ADASYN','-v7.3'); % Threshold 30%
%save('classification9KNN60ADASYN_20.mat','classification9KNN60ADASYN','-v7.3'); % Threshold 20%
%save('classification9KNN60ADASYN_10.mat','classification9KNN60ADASYN','-v7.3'); % Threshold 10%

save('classification5Tree60ADASYN.mat','classification5Tree60ADASYN','-v7.3'); % majority voting
%save('classification5Tree60ADASYN_30.mat','classification5Tree60ADASYN','-v7.3'); % Threshold 30%
%save('classification5Tree60ADASYN_20.mat','classification5Tree60ADASYN','-v7.3'); % Threshold 20%
%save('classification5Tree60ADASYN_10.mat','classification5Tree60ADASYN','-v7.3'); % Threshold 10%

save('classification10Tree60ADASYN.mat','classification10Tree60ADASYN','-v7.3'); % majority voting
%save('classification10Tree60ADASYN_30.mat','classification10Tree60ADASYN','-v7.3'); % Threshold 30%
%save('classification10Tree60ADASYN_20.mat','classification10Tree60ADASYN','-v7.3'); % Threshold 20%
%save('classification10Tree60ADASYN_10.mat','classification10Tree60ADASYN','-v7.3'); % Threshold 10%

save('classification20Tree60ADASYN.mat','classification20Tree60ADASYN','-v7.3'); % majority voting
%save('classification20Tree60ADASYN_30.mat','classification20Tree60ADASYN','-v7.3'); % Threshold 30%
%save('classification20Tree60ADASYN_20.mat','classification20Tree60ADASYN','-v7.3'); % Threshold 20%
%save('classification20Tree60ADASYN_10.mat','classification20Tree60ADASYN','-v7.3'); % Threshold 10%

save('classification30Tree60ADASYN.mat','classification30Tree60ADASYN','-v7.3'); % majority voting
%save('classification30Tree60ADASYN_30.mat','classification30Tree60ADASYN','-v7.3'); % Threshold 30%
%save('classification30Tree60ADASYN_20.mat','classification30Tree60ADASYN','-v7.3'); % Threshold 20%
%save('classification30Tree60ADASYN_10.mat','classification30Tree60ADASYN','-v7.3'); % Threshold 10%

save('classification40Tree60ADASYN.mat','classification40Tree60ADASYN','-v7.3'); % majority voting
%save('classification40Tree60ADASYN_30.mat','classification40Tree60ADASYN','-v7.3'); % Threshold 30%
%save('classification40Tree60ADASYN_20.mat','classification40Tree60ADASYN','-v7.3'); % Threshold 20%
%save('classification40Tree60ADASYN_10.mat','classification40Tree60ADASYN','-v7.3'); % Threshold 10%

save('classification50Tree60ADASYN.mat','classification50Tree60ADASYN','-v7.3'); % majority voting
%save('classification50Tree60ADASYN_30.mat','classification50Tree60ADASYN','-v7.3'); % Threshold 30%
%save('classification50Tree60ADASYN_20.mat','classification50Tree60ADASYN','-v7.3'); % Threshold 20%
%save('classification50Tree60ADASYN_10.mat','classification50Tree60ADASYN','-v7.3'); % Threshold 10%


m1 = mean([t1{:}]);
m2 = mean([t2{:}]);
m3 = mean([t3{:}]);
m4 = mean([t4{:}]);
m5 = mean([t5{:}]);
m6 = mean([t6{:}]);
m7 = mean([t7{:}]);
m8 = mean([t8{:}]);
m9 = mean([t9{:}]);
m10 = mean([t10{:}]);
m11 = mean([t11{:}]);
m12 = mean([t12{:}]);
m13 = mean([t13{:}]);
m14 = mean([t14{:}]);

s1 = sum([t1{:}]);
s2 = sum([t2{:}]);
s3 = sum([t3{:}]);
s4 = sum([t4{:}]);
s5 = sum([t5{:}]);
s6 = sum([t6{:}]);
s7 = sum([t7{:}]);
s8 = sum([t8{:}]);
s9 = sum([t9{:}]);
s10 = sum([t10{:}]);
s11 = sum([t11{:}]);
s12 = sum([t12{:}]);
s13 = sum([t13{:}]);
s14 = sum([t14{:}]);




% Linear SVM
[xLinSVM60ADASYNtrain,yLinSVM60ADASYNtrain,~,aucLinSVM60ADASYNtrain] = perfcurve(targetsLinSVM60ADASYNtrain_all,scoresLinSVM60ADASYNtrain_all,1);
[xLinSVM60ADASYNtest,yLinSVM60ADASYNtest,~,aucLinSVM60ADASYNtest] = perfcurve(targetsLinSVM60ADASYNtest_all,scoresLinSVM60ADASYNtest_all,1);

% Quadratic SVM
[xQuadSVM60ADASYNtrain,yQuadSVM60ADASYNtrain,~,aucQuadSVM60ADASYNtrain] = perfcurve(targetsQuadSVM60ADASYNtrain_all,scoresQuadSVM60ADASYNtrain_all,1);
[xQuadSVM60ADASYNtest,yQuadSVM60ADASYNtest,~,aucQuadSVM60ADASYNtest] = perfcurve(targetsQuadSVM60ADASYNtest_all,scoresQuadSVM60ADASYNtest_all,1);

% Cubic SVM
[xCubicSVM60ADASYNtrain,yCubicSVM60ADASYNtrain,~,aucCubicSVM60ADASYNtrain] = perfcurve(targetsCubicSVM60ADASYNtrain_all,scoresCubicSVM60ADASYNtrain_all,1);
[xCubicSVM60ADASYNtest,yCubicSVM60ADASYNtest,~,aucCubicSVM60ADASYNtest] = perfcurve(targetsCubicSVM60ADASYNtest_all,scoresCubicSVM60ADASYNtest_all,1);

% RBF SVM
[xRBFSVM60ADASYNtrain,yRBFSVM60ADASYNtrain,~,aucRBFSVM60ADASYNtrain] = perfcurve(targetsRBFSVM60ADASYNtrain_all,scoresRBFSVM60ADASYNtrain_all,1);
[xRBFSVM60ADASYNtest,yRBFSVM60ADASYNtest,~,aucRBFSVM60ADASYNtest] = perfcurve(targetsRBFSVM60ADASYNtest_all,scoresRBFSVM60ADASYNtest_all,1);

% kNN, 3 neighbors
[x3KNN60ADASYNtrain,y3KNN60ADASYNtrain,~,auc3KNN60ADASYNtrain] = perfcurve(targets3KNN60ADASYNtrain_all,scores3KNN60ADASYNtrain_all,1);
[x3KNN60ADASYNtest,y3KNN60ADASYNtest,~,auc3KNN60ADASYNtest] = perfcurve(targets3KNN60ADASYNtest_all,scores3KNN60ADASYNtest_all,1);

% kNN, 5 neighbors
[x5KNN60ADASYNtrain,y5KNN60ADASYNtrain,~,auc5KNN60ADASYNtrain] = perfcurve(targets5KNN60ADASYNtrain_all,scores5KNN60ADASYNtrain_all,1);
[x5KNN60ADASYNtest,y5KNN60ADASYNtest,~,auc5KNN60ADASYNtest] = perfcurve(targets5KNN60ADASYNtest_all,scores5KNN60ADASYNtest_all,1);

% kNN, 7 neighbors
[x7KNN60ADASYNtrain,y7KNN60ADASYNtrain,~,auc7KNN60ADASYNtrain] = perfcurve(targets7KNN60ADASYNtrain_all,scores7KNN60ADASYNtrain_all,1);
[x7KNN60ADASYNtest,y7KNN60ADASYNtest,~,auc7KNN60ADASYNtest] = perfcurve(targets7KNN60ADASYNtest_all,scores7KNN60ADASYNtest_all,1);

% kNN, 9 neighbors
[x9KNN60ADASYNtrain,y9KNN60ADASYNtrain,~,auc9KNN60ADASYNtrain] = perfcurve(targets9KNN60ADASYNtrain_all,scores9KNN60ADASYNtrain_all,1);
[x9KNN60ADASYNtest,y9KNN60ADASYNtest,~,auc9KNN60ADASYNtest] = perfcurve(targets9KNN60ADASYNtest_all,scores9KNN60ADASYNtest_all,1);

% RF, 5 Trees
[x5Tree60ADASYNtrain,y5Tree60ADASYNtrain,~,auc5Tree60ADASYNtrain] = perfcurve(targets5Tree60ADASYNtrain_all,scores5Tree60ADASYNtrain_all,1);
[x5Tree60ADASYNtest,y5Tree60ADASYNtest,~,auc5Tree60ADASYNtest] = perfcurve(targets5Tree60ADASYNtest_all,scores5Tree60ADASYNtest_all,1);

% RF, 10 Trees
[x10Tree60ADASYNtrain,y10Tree60ADASYNtrain,~,auc10Tree60ADASYNtrain] = perfcurve(targets10Tree60ADASYNtrain_all,scores10Tree60ADASYNtrain_all,1);
[x10Tree60ADASYNtest,y10Tree60ADASYNtest,~,auc10Tree60ADASYNtest] = perfcurve(targets10Tree60ADASYNtest_all,scores10Tree60ADASYNtest_all,1);

% RF, 20 Trees
[x20Tree60ADASYNtrain,y20Tree60ADASYNtrain,~,auc20Tree60ADASYNtrain] = perfcurve(targets20Tree60ADASYNtrain_all,scores20Tree60ADASYNtrain_all,1);
[x20Tree60ADASYNtest,y20Tree60ADASYNtest,~,auc20Tree60ADASYNtest] = perfcurve(targets20Tree60ADASYNtest_all,scores20Tree60ADASYNtest_all,1);

% RF, 30 Trees
[x30Tree60ADASYNtrain,y30Tree60ADASYNtrain,~,auc30Tree60ADASYNtrain] = perfcurve(targets30Tree60ADASYNtrain_all,scores30Tree60ADASYNtrain_all,1);
[x30Tree60ADASYNtest,y30Tree60ADASYNtest,~,auc30Tree60ADASYNtest] = perfcurve(targets30Tree60ADASYNtest_all,scores30Tree60ADASYNtest_all,1);

% RF, 40 Trees
[x40Tree60ADASYNtrain,y40Tree60ADASYNtrain,~,auc40Tree60ADASYNtrain] = perfcurve(targets40Tree60ADASYNtrain_all,scores40Tree60ADASYNtrain_all,1);
[x40Tree60ADASYNtest,y40Tree60ADASYNtest,~,auc40Tree60ADASYNtest] = perfcurve(targets40Tree60ADASYNtest_all,scores40Tree60ADASYNtest_all,1);

% RF, 50 Trees
[x50Tree60ADASYNtrain,y50Tree60ADASYNtrain,~,auc50Tree60ADASYNtrain] = perfcurve(targets50Tree60ADASYNtrain_all,scores50Tree60ADASYNtrain_all,1);
[x50Tree60ADASYNtest,y50Tree60ADASYNtest,~,auc50Tree60ADASYNtest] = perfcurve(targets50Tree60ADASYNtest_all,scores50Tree60ADASYNtest_all,1);

% Confusion matrices
figure()
subplot(121)
confusionchart(targetsLinSVM60ADASYNtrain_all,predsLinSVM60ADASYNtrain_all);
title('Linear SVM, training')
subplot(122)
confusionchart(targetsLinSVM60ADASYNtest_all,predsLinSVM60ADASYNtest_all);
title('Linear SVM, validation')

figure()
subplot(121)
confusionchart(targetsQuadSVM60ADASYNtrain_all,predsQuadSVM60ADASYNtrain_all);
title('Quadratic SVM, training')
subplot(122)
confusionchart(targetsQuadSVM60ADASYNtest_all,predsQuadSVM60ADASYNtest_all);
title('Quadratic SVM, validation')

figure()
subplot(121)
confusionchart(targetsCubicSVM60ADASYNtrain_all,predsCubicSVM60ADASYNtrain_all);
title('Cubic SVM, training')
subplot(122)
confusionchart(targetsCubicSVM60ADASYNtest_all,predsCubicSVM60ADASYNtest_all);
title('Cubic SVM, validation')

figure()
subplot(121)
confusionchart(targetsRBFSVM60ADASYNtrain_all,predsRBFSVM60ADASYNtrain_all);
title('RBF SVM, training')
subplot(122)
confusionchart(targetsRBFSVM60ADASYNtest_all,predsRBFSVM60ADASYNtest_all);
title('RBF SVM, validation')

figure()
subplot(121)
confusionchart(targets3KNN60ADASYNtrain_all,preds3KNN60ADASYNtrain_all);
title('kNN - k = 3, training')
subplot(122)
confusionchart(targets3KNN60ADASYNtest_all,preds3KNN60ADASYNtest_all);
title('kNN - k = 3, validation')

figure()
subplot(121)
confusionchart(targets5KNN60ADASYNtrain_all,preds5KNN60ADASYNtrain_all);
title('kNN - k = 5, training')
subplot(122)
confusionchart(targets5KNN60ADASYNtest_all,preds5KNN60ADASYNtest_all);
title('kNN - k = 5, validation')

figure()
subplot(121)
confusionchart(targets7KNN60ADASYNtrain_all,preds7KNN60ADASYNtrain_all);
title('kNN - k = 7, training')
subplot(122)
confusionchart(targets7KNN60ADASYNtest_all,preds7KNN60ADASYNtest_all);
title('kNN - k = 7, validation')

figure()
subplot(121)
confusionchart(targets9KNN60ADASYNtrain_all,preds9KNN60ADASYNtrain_all);
title('kNN - k = 9, training')
subplot(122)
confusionchart(targets9KNN60ADASYNtest_all,preds9KNN60ADASYNtest_all);
title('kNN - k = 9, validation')

figure()
subplot(121)
confusionchart(targets5Tree60ADASYNtrain_all,preds5Tree60ADASYNtrain_all);
title('RF 5 Trees, training')
subplot(122)
confusionchart(targets5Tree60ADASYNtest_all,preds5Tree60ADASYNtest_all);
title('RF 5 Trees, validation')

figure()
subplot(121)
confusionchart(targets10Tree60ADASYNtrain_all,preds10Tree60ADASYNtrain_all);
title('RF 10 Trees, training')
subplot(122)
confusionchart(targets10Tree60ADASYNtest_all,preds10Tree60ADASYNtest_all);
title('RF 10 Trees, validation')

figure()
subplot(121)
confusionchart(targets20Tree60ADASYNtrain_all,preds20Tree60ADASYNtrain_all);
title('RF 20 Trees, training')
subplot(122)
confusionchart(targets20Tree60ADASYNtest_all,preds20Tree60ADASYNtest_all);
title('RF 20 Trees, validation')

figure()
subplot(121)
confusionchart(targets30Tree60ADASYNtrain_all,preds30Tree60ADASYNtrain_all);
title('RF 30 Trees, training')
subplot(122)
confusionchart(targets30Tree60ADASYNtest_all,preds30Tree60ADASYNtest_all);
title('RF 30 Trees, validation')

figure()
subplot(121)
confusionchart(targets40Tree60ADASYNtrain_all,preds40Tree60ADASYNtrain_all);
title('RF 40 Trees, training')
subplot(122)
confusionchart(targets40Tree60ADASYNtest_all,preds40Tree60ADASYNtest_all);
title('RF 40 Trees, validation')

figure()
subplot(121)
confusionchart(targets50Tree60ADASYNtrain_all,preds50Tree60ADASYNtrain_all);
title('RF 50 Trees, training')
subplot(122)
confusionchart(targets50Tree60ADASYNtest_all,preds50Tree60ADASYNtest_all);
title('RF 50 Trees, validation')


% % ROC curve plots, training and validation
figure()
plot(xLinSVM60ADASYNtrain,yLinSVM60ADASYNtrain,'LineWidth',2)
hold on
plot(xLinSVM60ADASYNtest,yLinSVM60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, Linear SVM')
legend('Training', 'Validation')
hold off

figure()
plot(xQuadSVM60ADASYNtrain,yQuadSVM60ADASYNtrain,'LineWidth',2)
hold on
plot(xQuadSVM60ADASYNtest,yQuadSVM60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, Quadratic SVM')
legend('Training', 'Validation')
hold off

figure()
plot(xCubicSVM60ADASYNtrain,yCubicSVM60ADASYNtrain,'LineWidth',2)
hold on
plot(xCubicSVM60ADASYNtest,yCubicSVM60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, Cubic SVM')
legend('Training', 'Validation')
hold off

figure()
plot(xRBFSVM60ADASYNtrain,yRBFSVM60ADASYNtrain,'LineWidth',2)
hold on
plot(xRBFSVM60ADASYNtest,yRBFSVM60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RBF SVM')
legend('Training', 'Validation')
hold off

figure()
plot(x3KNN60ADASYNtrain,y3KNN60ADASYNtrain,'LineWidth',2)
hold on
plot(x3KNN60ADASYNtest,y3KNN60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 3')
legend('Training', 'Validation')
hold off

figure()
plot(x5KNN60ADASYNtrain,y5KNN60ADASYNtrain,'LineWidth',2)
hold on
plot(x5KNN60ADASYNtest,y5KNN60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 5')
legend('Training', 'Validation')
hold off

figure()
plot(x7KNN60ADASYNtrain,y7KNN60ADASYNtrain,'LineWidth',2)
hold on
plot(x7KNN60ADASYNtest,y7KNN60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 7')
legend('Training', 'Validation')
hold off

figure()
plot(x9KNN60ADASYNtrain,y9KNN60ADASYNtrain,'LineWidth',2)
hold on
plot(x9KNN60ADASYNtest,y9KNN60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, kNN - k = 9')
legend('Training', 'Validation')
hold off

figure()
plot(x5Tree60ADASYNtrain,y5Tree60ADASYNtrain,'LineWidth',2)
hold on
plot(x5Tree60ADASYNtest,y5Tree60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 5 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x10Tree60ADASYNtrain,y10Tree60ADASYNtrain,'LineWidth',2)
hold on
plot(x10Tree60ADASYNtest,y10Tree60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 10 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x20Tree60ADASYNtrain,y20Tree60ADASYNtrain,'LineWidth',2)
hold on
plot(x20Tree60ADASYNtest,y20Tree60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 20 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x30Tree60ADASYNtrain,y30Tree60ADASYNtrain,'LineWidth',2)
hold on
plot(x30Tree60ADASYNtest,y30Tree60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 30 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x40Tree60ADASYNtrain,y40Tree60ADASYNtrain,'LineWidth',2)
hold on
plot(x40Tree60ADASYNtest,y40Tree60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 40 Trees')
legend('Training', 'Validation')
hold off

figure()
plot(x50Tree60ADASYNtrain,y50Tree60ADASYNtrain,'LineWidth',2)
hold on
plot(x50Tree60ADASYNtest,y50Tree60ADASYNtest,'r','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, RF 50 Trees')
legend('Training', 'Validation')
hold off


% ROC curve plots, validation only, all models.
figure()
plot(xLinSVM60ADASYNtest,yLinSVM60ADASYNtest,'r','LineWidth',2)
hold on
plot(xQuadSVM60ADASYNtest,yQuadSVM60ADASYNtest,'g','LineWidth',2)
plot(xCubicSVM60ADASYNtest,yCubicSVM60ADASYNtest,'b','LineWidth',2)
plot(xRBFSVM60ADASYNtest,yRBFSVM60ADASYNtest,'c','LineWidth',2)
plot(x3KNN60ADASYNtest,y3KNN60ADASYNtest,'m','LineWidth',2)
plot(x5KNN60ADASYNtest,y5KNN60ADASYNtest,'y','LineWidth',2)
plot(x7KNN60ADASYNtest,y7KNN60ADASYNtest,'k','LineWidth',2)
plot(x9KNN60ADASYNtest,y9KNN60ADASYNtest,'r--','LineWidth',2)
plot(x5Tree60ADASYNtest,y5Tree60ADASYNtest,'g--','LineWidth',2)
plot(x10Tree60ADASYNtest,y10Tree60ADASYNtest,'b--','LineWidth',2)
plot(x20Tree60ADASYNtest,y20Tree60ADASYNtest,'c--','LineWidth',2)
plot(x30Tree60ADASYNtest,y30Tree60ADASYNtest,'m--','LineWidth',2)
plot(x40Tree60ADASYNtest,y40Tree60ADASYNtest,'y--','LineWidth',2)
plot(x50Tree60ADASYNtest,y50Tree60ADASYNtest,'k--','LineWidth',2)
xlabel('False Positive Rate')
ylabel('True Positive Rate')
title('ROC, all models, validation only')
legend('Linear SVM', 'Quadratic SVM','Cubic SVM','RBF SVM','kNN, k=3',...
    'kNN, k=5','kNN, k=7','kNN, k=9','RF, 5 Trees', 'RF, 10 Trees',...
    'RF, 20 Trees','RF, 30 Trees','RF, 40 Trees', 'RF, 50 Trees','Location','SouthEast')

AUCtrain = [aucLinSVM60ADASYNtrain;aucQuadSVM60ADASYNtrain;aucCubicSVM60ADASYNtrain;aucRBFSVM60ADASYNtrain;...
    auc3KNN60ADASYNtrain;auc5KNN60ADASYNtrain;auc7KNN60ADASYNtrain;auc9KNN60ADASYNtrain;auc5Tree60ADASYNtrain;...
    auc10Tree60ADASYNtrain;auc20Tree60ADASYNtrain;auc30Tree60ADASYNtrain;auc40Tree60ADASYNtrain;...
    auc50Tree60ADASYNtrain];

AUCtest = [aucLinSVM60ADASYNtest;aucQuadSVM60ADASYNtest;aucCubicSVM60ADASYNtest;aucRBFSVM60ADASYNtest;...
    auc3KNN60ADASYNtest;auc5KNN60ADASYNtest;auc7KNN60ADASYNtest;auc9KNN60ADASYNtest;auc5Tree60ADASYNtest;...
    auc10Tree60ADASYNtest;auc20Tree60ADASYNtest;auc30Tree60ADASYNtest;auc40Tree60ADASYNtest;...
    auc50Tree60ADASYNtest];

meanTime = [m1;m2;m3;m4;m5;m6;m7;m8;m9;m10;m11;m12;m13;m14];
totalTime = [s1;s2;s3;s4;s5;s6;s7;s8;s9;s10;s11;s12;s13;s14];

T = table(AUCtrain,AUCtest,meanTime,totalTime);
